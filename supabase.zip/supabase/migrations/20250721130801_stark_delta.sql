-- Initialize Codie database

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enum types
CREATE TYPE analysis_type AS ENUM ('static', 'dynamic', 'security', 'full');
CREATE TYPE analysis_status AS ENUM ('pending', 'running', 'completed', 'failed');
CREATE TYPE finding_type AS ENUM ('security', 'performance', 'style', 'maintainability', 'testing', 'architecture', 'documentation');
CREATE TYPE severity AS ENUM ('critical', 'high', 'medium', 'low', 'info');

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_analyses_repository_id ON analyses(repository_id);
CREATE INDEX IF NOT EXISTS idx_analyses_user_id ON analyses(user_id);
CREATE INDEX IF NOT EXISTS idx_analyses_status ON analyses(status);
CREATE INDEX IF NOT EXISTS idx_analyses_created_at ON analyses(created_at);

CREATE INDEX IF NOT EXISTS idx_findings_analysis_id ON findings(analysis_id);
CREATE INDEX IF NOT EXISTS idx_findings_severity ON findings(severity);
CREATE INDEX IF NOT EXISTS idx_findings_finding_type ON findings(finding_type);
CREATE INDEX IF NOT EXISTS idx_findings_confidence_score ON findings(confidence_score);

CREATE INDEX IF NOT EXISTS idx_repositories_owner_id ON repositories(owner_id);
CREATE INDEX IF NOT EXISTS idx_repositories_created_at ON repositories(created_at);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_is_active ON users(is_active);

-- Insert sample data for development
INSERT INTO users (id, email, hashed_password, full_name, is_active, is_superuser) VALUES
    (uuid_generate_v4(), 'demo@codie.ai', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6hsxq5/Hxe', 'Demo User', true, false),
    (uuid_generate_v4(), 'admin@codie.ai', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj6hsxq5/Hxe', 'Admin User', true, true);

-- Create sample repository
INSERT INTO repositories (id, name, url, description, languages, owner_id) VALUES
    (uuid_generate_v4(), 'sample-project', 'https://github.com/user/sample-project', 'Sample project for demonstration', '["python", "javascript"]', (SELECT id FROM users WHERE email = 'demo@codie.ai' LIMIT 1));