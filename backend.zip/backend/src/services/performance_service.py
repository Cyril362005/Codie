"""
Performance analysis service for runtime testing and optimization
"""
import asyncio
import json
import os
import subprocess
import tempfile
import time
from typing import Dict, List, Optional

import structlog

logger = structlog.get_logger()


class PerformanceService:
    """Service for performance analysis and runtime testing"""
    
    def __init__(self):
        self.supported_languages = ['python', 'javascript', 'java']
    
    async def analyze_performance(self, repo_path: str) -> Dict:
        """Analyze repository performance characteristics"""
        logger.info("Starting performance analysis", repo_path=repo_path)
        
        results = {
            'test_execution': {},
            'static_analysis': {},
            'recommendations': []
        }
        
        # Detect project type and run appropriate tests
        project_type = self._detect_project_type(repo_path)
        
        if project_type == 'python':
            results['test_execution'] = await self._analyze_python_performance(repo_path)
        elif project_type == 'javascript':
            results['test_execution'] = await self._analyze_javascript_performance(repo_path)
        elif project_type == 'java':
            results['test_execution'] = await self._analyze_java_performance(repo_path)
        
        # Static performance analysis
        results['static_analysis'] = await self._static_performance_analysis(repo_path)
        
        # Generate recommendations
        results['recommendations'] = self._generate_performance_recommendations(results)
        
        logger.info("Performance analysis completed")
        return results
    
    def _detect_project_type(self, repo_path: str) -> Optional[str]:
        """Detect the primary project type"""
        # Check for common project files
        if os.path.exists(os.path.join(repo_path, 'requirements.txt')) or \
           os.path.exists(os.path.join(repo_path, 'setup.py')) or \
           os.path.exists(os.path.join(repo_path, 'pyproject.toml')):
            return 'python'
        
        if os.path.exists(os.path.join(repo_path, 'package.json')):
            return 'javascript'
        
        if os.path.exists(os.path.join(repo_path, 'pom.xml')) or \
           os.path.exists(os.path.join(repo_path, 'build.gradle')):
            return 'java'
        
        return None
    
    async def _analyze_python_performance(self, repo_path: str) -> Dict:
        """Analyze Python project performance"""
        results = {
            'test_results': {},
            'execution_time': 0,
            'memory_usage': {},
            'coverage': 0
        }
        
        try:
            # Check if pytest is available
            test_command = ['python', '-m', 'pytest', '--tb=short', '-v']
            
            start_time = time.time()
            
            # Run tests with timeout
            process = await asyncio.create_subprocess_exec(
                *test_command,
                cwd=repo_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=60)
                execution_time = time.time() - start_time
                
                results['execution_time'] = execution_time
                results['test_results'] = {
                    'status': 'completed' if process.returncode == 0 else 'failed',
                    'return_code': process.returncode,
                    'stdout': stdout.decode('utf-8', errors='ignore')[:1000],  # Limit output
                    'stderr': stderr.decode('utf-8', errors='ignore')[:1000]
                }
                
                # Mock memory usage (in real implementation, use memory profiling)
                results['memory_usage'] = {
                    'peak_memory_mb': 45.2,
                    'average_memory_mb': 32.1,
                    'memory_leaks_detected': False
                }
                
            except asyncio.TimeoutError:
                process.kill()
                results['test_results'] = {
                    'status': 'timeout',
                    'message': 'Test execution timed out after 60 seconds'
                }
                
        except Exception as e:
            logger.error("Python performance analysis failed", error=str(e))
            results['test_results'] = {
                'status': 'error',
                'message': str(e)
            }
        
        return results
    
    async def _analyze_javascript_performance(self, repo_path: str) -> Dict:
        """Analyze JavaScript/Node.js project performance"""
        results = {
            'test_results': {},
            'execution_time': 0,
            'memory_usage': {},
            'bundle_analysis': {}
        }
        
        try:
            # Check for npm test script
            package_json_path = os.path.join(repo_path, 'package.json')
            if os.path.exists(package_json_path):
                with open(package_json_path, 'r') as f:
                    package_data = json.load(f)
                
                scripts = package_data.get('scripts', {})
                if 'test' in scripts:
                    test_command = ['npm', 'test']
                    
                    start_time = time.time()
                    
                    process = await asyncio.create_subprocess_exec(
                        *test_command,
                        cwd=repo_path,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE
                    )
                    
                    try:
                        stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=90)
                        execution_time = time.time() - start_time
                        
                        results['execution_time'] = execution_time
                        results['test_results'] = {
                            'status': 'completed' if process.returncode == 0 else 'failed',
                            'return_code': process.returncode,
                            'stdout': stdout.decode('utf-8', errors='ignore')[:1000],
                            'stderr': stderr.decode('utf-8', errors='ignore')[:1000]
                        }
                        
                        # Mock bundle analysis
                        results['bundle_analysis'] = {
                            'bundle_size_kb': 245.7,
                            'gzip_size_kb': 78.3,
                            'unused_code_percentage': 12.5,
                            'large_dependencies': ['lodash', 'moment']
                        }
                        
                    except asyncio.TimeoutError:
                        process.kill()
                        results['test_results'] = {
                            'status': 'timeout',
                            'message': 'Test execution timed out after 90 seconds'
                        }
                        
        except Exception as e:
            logger.error("JavaScript performance analysis failed", error=str(e))
            results['test_results'] = {
                'status': 'error',
                'message': str(e)
            }
        
        return results
    
    async def _analyze_java_performance(self, repo_path: str) -> Dict:
        """Analyze Java project performance"""
        results = {
            'test_results': {},
            'execution_time': 0,
            'memory_usage': {},
            'jvm_metrics': {}
        }
        
        try:
            # Check for Maven or Gradle
            if os.path.exists(os.path.join(repo_path, 'pom.xml')):
                test_command = ['mvn', 'test']
            elif os.path.exists(os.path.join(repo_path, 'build.gradle')):
                test_command = ['./gradlew', 'test']
            else:
                results['test_results'] = {
                    'status': 'skipped',
                    'message': 'No Maven or Gradle build file found'
                }
                return results
            
            start_time = time.time()
            
            process = await asyncio.create_subprocess_exec(
                *test_command,
                cwd=repo_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            
            try:
                stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=120)
                execution_time = time.time() - start_time
                
                results['execution_time'] = execution_time
                results['test_results'] = {
                    'status': 'completed' if process.returncode == 0 else 'failed',
                    'return_code': process.returncode,
                    'stdout': stdout.decode('utf-8', errors='ignore')[:1000],
                    'stderr': stderr.decode('utf-8', errors='ignore')[:1000]
                }
                
                # Mock JVM metrics
                results['jvm_metrics'] = {
                    'heap_usage_mb': 128.5,
                    'gc_time_ms': 45,
                    'class_loading_time_ms': 234,
                    'compilation_time_ms': 567
                }
                
            except asyncio.TimeoutError:
                process.kill()
                results['test_results'] = {
                    'status': 'timeout',
                    'message': 'Test execution timed out after 120 seconds'
                }
                
        except Exception as e:
            logger.error("Java performance analysis failed", error=str(e))
            results['test_results'] = {
                'status': 'error',
                'message': str(e)
            }
        
        return results
    
    async def _static_performance_analysis(self, repo_path: str) -> Dict:
        """Perform static analysis for performance issues"""
        analysis = {
            'complexity_metrics': {},
            'performance_antipatterns': [],
            'optimization_opportunities': []
        }
        
        # Analyze file complexity and size
        total_files = 0
        total_lines = 0
        large_files = []
        
        for root, dirs, files in os.walk(repo_path):
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['node_modules', '__pycache__', 'target']]
            
            for file in files:
                if file.endswith(('.py', '.js', '.ts', '.java')):
                    file_path = os.path.join(root, file)
                    relative_path = os.path.relpath(file_path, repo_path)
                    
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                        
                        lines = content.count('\n') + 1
                        total_files += 1
                        total_lines += lines
                        
                        if lines > 500:
                            large_files.append({
                                'file': relative_path,
                                'lines': lines,
                                'recommendation': 'Consider breaking down large files'
                            })
                            
                    except Exception:
                        continue
        
        analysis['complexity_metrics'] = {
            'total_files': total_files,
            'total_lines': total_lines,
            'average_file_size': total_lines / max(total_files, 1),
            'large_files_count': len(large_files)
        }
        
        # Mock performance antipatterns
        analysis['performance_antipatterns'] = [
            {
                'pattern': 'N+1 Query Pattern',
                'files_affected': 2,
                'severity': 'high',
                'description': 'Database queries executed in loops'
            },
            {
                'pattern': 'Inefficient String Concatenation',
                'files_affected': 3,
                'severity': 'medium',
                'description': 'String concatenation in loops'
            }
        ]
        
        analysis['optimization_opportunities'] = large_files[:5]  # Top 5 large files
        
        return analysis
    
    def _generate_performance_recommendations(self, results: Dict) -> List[Dict]:
        """Generate performance improvement recommendations"""
        recommendations = []
        
        # Test execution recommendations
        test_results = results.get('test_execution', {})
        if test_results.get('execution_time', 0) > 30:
            recommendations.append({
                'type': 'test_performance',
                'priority': 'high',
                'title': 'Slow test execution detected',
                'description': f"Tests took {test_results['execution_time']:.1f} seconds to complete",
                'recommendation': 'Consider parallelizing tests or optimizing slow test cases'
            })
        
        # Memory usage recommendations
        memory_usage = test_results.get('memory_usage', {})
        if memory_usage.get('peak_memory_mb', 0) > 100:
            recommendations.append({
                'type': 'memory_optimization',
                'priority': 'medium',
                'title': 'High memory usage detected',
                'description': f"Peak memory usage: {memory_usage['peak_memory_mb']}MB",
                'recommendation': 'Profile memory usage and optimize data structures'
            })
        
        # Bundle size recommendations (JavaScript)
        bundle_analysis = test_results.get('bundle_analysis', {})
        if bundle_analysis.get('bundle_size_kb', 0) > 200:
            recommendations.append({
                'type': 'bundle_optimization',
                'priority': 'medium',
                'title': 'Large bundle size detected',
                'description': f"Bundle size: {bundle_analysis['bundle_size_kb']}KB",
                'recommendation': 'Consider code splitting and tree shaking to reduce bundle size'
            })
        
        # Static analysis recommendations
        static_analysis = results.get('static_analysis', {})
        complexity_metrics = static_analysis.get('complexity_metrics', {})
        if complexity_metrics.get('large_files_count', 0) > 0:
            recommendations.append({
                'type': 'code_organization',
                'priority': 'low',
                'title': 'Large files detected',
                'description': f"{complexity_metrics['large_files_count']} files exceed 500 lines",
                'recommendation': 'Break down large files into smaller, focused modules'
            })
        
        return recommendations