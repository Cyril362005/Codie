"""
AI service for conversational code review and explanations
"""
import json
from typing import Dict, List, Optional

import openai
import structlog

from src.core.config import get_settings
from src.models.chat import ChatMessage, ChatResponse

logger = structlog.get_logger()
settings = get_settings()


class AIService:
    """Service for AI-powered code analysis and chat"""
    
    def __init__(self):
        if settings.OPENAI_API_KEY:
            openai.api_key = settings.OPENAI_API_KEY
        else:
            logger.warning("OpenAI API key not configured, AI features will be limited")
    
    async def chat_about_code(
        self, 
        message: str, 
        context: Dict, 
        conversation_history: List[ChatMessage] = None
    ) -> ChatResponse:
        """Handle conversational queries about code analysis"""
        
        if not settings.OPENAI_API_KEY:
            return ChatResponse(
                message="AI features are not available. Please configure OpenAI API key.",
                confidence=0.0,
                suggestions=[]
            )
        
        try:
            # Build conversation context
            system_prompt = self._build_system_prompt(context)
            messages = [{"role": "system", "content": system_prompt}]
            
            # Add conversation history
            if conversation_history:
                for msg in conversation_history[-10:]:  # Keep last 10 messages
                    messages.append({
                        "role": "user" if msg.is_user else "assistant",
                        "content": msg.content
                    })
            
            # Add current message
            messages.append({"role": "user", "content": message})
            
            # Call OpenAI API
            response = await openai.ChatCompletion.acreate(
                model=settings.OPENAI_MODEL,
                messages=messages,
                max_tokens=1000,
                temperature=0.7
            )
            
            ai_response = response.choices[0].message.content
            
            # Extract code suggestions if any
            suggestions = self._extract_code_suggestions(ai_response, context)
            
            return ChatResponse(
                message=ai_response,
                confidence=0.9,  # High confidence for GPT-4 responses
                suggestions=suggestions,
                context=context
            )
            
        except Exception as e:
            logger.error("AI chat failed", error=str(e))
            return ChatResponse(
                message="I'm sorry, I encountered an error while processing your request. Please try again.",
                confidence=0.0,
                suggestions=[]
            )
    
    def _build_system_prompt(self, context: Dict) -> str:
        """Build system prompt with analysis context"""
        
        base_prompt = """You are Codie, an expert AI code review assistant. You help developers understand code quality issues, security vulnerabilities, and best practices.

Your responses should be:
- Clear and educational
- Focused on actionable advice
- Supportive and encouraging
- Technically accurate

When discussing code issues:
- Explain WHY something is a problem
- Provide specific examples when helpful
- Suggest concrete improvements
- Consider the broader context of the codebase"""
        
        # Add analysis context if available
        if context.get('findings'):
            findings_summary = f"\n\nCurrent analysis found {len(context['findings'])} issues across the codebase."
            base_prompt += findings_summary
        
        if context.get('file_path'):
            file_context = f"\n\nCurrently discussing: {context['file_path']}"
            base_prompt += file_context
        
        return base_prompt
    
    def _extract_code_suggestions(self, response: str, context: Dict) -> List[Dict]:
        """Extract actionable code suggestions from AI response"""
        suggestions = []
        
        # Look for code blocks in the response
        if "```" in response:
            # Simple extraction of code blocks
            parts = response.split("```")
            for i in range(1, len(parts), 2):  # Every other part is code
                code_block = parts[i].strip()
                if code_block:
                    # Remove language identifier if present
                    lines = code_block.split('\n')
                    if lines[0] in ['python', 'javascript', 'java', 'typescript']:
                        code_block = '\n'.join(lines[1:])
                    
                    suggestions.append({
                        "type": "code_replacement",
                        "code": code_block,
                        "description": "Suggested code improvement"
                    })
        
        return suggestions
    
    async def explain_finding(self, finding: Dict, code_context: str = "") -> str:
        """Generate detailed explanation for a specific finding"""
        
        if not settings.OPENAI_API_KEY:
            return "AI explanations are not available. Please configure OpenAI API key."
        
        try:
            prompt = f"""Explain this code analysis finding in detail:

Finding Type: {finding.get('finding_type', 'Unknown')}
Severity: {finding.get('severity', 'Unknown')}
Title: {finding.get('title', 'No title')}
Description: {finding.get('description', 'No description')}
File: {finding.get('file_path', 'Unknown file')}
Line: {finding.get('line_start', 'Unknown')}

{f"Code Context:\n{code_context}" if code_context else ""}

Please explain:
1. Why this is an issue
2. What problems it could cause
3. How to fix it
4. Best practices to prevent it in the future

Keep the explanation clear and educational."""

            response = await openai.ChatCompletion.acreate(
                model=settings.OPENAI_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=800,
                temperature=0.7
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error("Finding explanation failed", error=str(e))
            return "I'm sorry, I couldn't generate an explanation for this finding. Please try again later."
    
    async def suggest_refactoring(self, code: str, language: str, issues: List[Dict]) -> Dict:
        """Suggest refactoring improvements for code"""
        
        if not settings.OPENAI_API_KEY:
            return {"error": "AI features not available"}
        
        try:
            issues_summary = "\n".join([
                f"- {issue.get('title', 'Unknown issue')}: {issue.get('description', '')}"
                for issue in issues[:5]  # Limit to top 5 issues
            ])
            
            prompt = f"""Analyze this {language} code and suggest refactoring improvements:

Code:
```{language}
{code}
```

Known Issues:
{issues_summary}

Please provide:
1. Specific refactoring recommendations
2. Improved code example
3. Explanation of benefits
4. Step-by-step refactoring plan

Focus on the most impactful improvements first."""

            response = await openai.ChatCompletion.acreate(
                model=settings.OPENAI_MODEL,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=1200,
                temperature=0.7
            )
            
            return {
                "recommendations": response.choices[0].message.content,
                "confidence": 0.85
            }
            
        except Exception as e:
            logger.error("Refactoring suggestion failed", error=str(e))
            return {"error": "Failed to generate refactoring suggestions"}