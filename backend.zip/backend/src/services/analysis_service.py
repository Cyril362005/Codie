"""
Core analysis service for code review and quality assessment
"""
import asyncio
import json
import os
import tempfile
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import uuid

import git
import structlog
import tree_sitter_python as tspython
import tree_sitter_javascript as tsjavascript
import tree_sitter_java as tsjava
from tree_sitter import Language, Parser
import redis
import json as _json

from src.core.config import get_settings
from src.models.analysis import AnalysisRequest, AnalysisResult, Finding
from src.services.security_service import SecurityService
from src.services.performance_service import PerformanceService
from src.core.celery_app import celery_app

logger = structlog.get_logger()
settings = get_settings()
redis_client = redis.Redis.from_url(settings.REDIS_URL)


class AnalysisService:
    """Main service for code analysis"""
    
    def __init__(self):
        self.security_service = SecurityService()
        self.performance_service = PerformanceService()
        self._setup_parsers()
    
    def _setup_parsers(self):
        """Initialize Tree-sitter parsers for different languages"""
        try:
            # Build language libraries
            self.languages = {
                'python': Language(tspython.language(), 'python'),
                'javascript': Language(tsjavascript.language(), 'javascript'),
                'typescript': Language(tsjavascript.language(), 'typescript'),
                'java': Language(tsjava.language(), 'java')
            }
            
            # Create parsers
            self.parsers = {}
            for lang_name, language in self.languages.items():
                parser = Parser()
                parser.set_language(language)
                self.parsers[lang_name] = parser
                
            logger.info("Tree-sitter parsers initialized", languages=list(self.languages.keys()))
            
        except Exception as e:
            logger.error("Failed to initialize parsers", error=str(e))
            self.languages = {}
            self.parsers = {}
    
    async def analyze_repository(self, request: AnalysisRequest) -> AnalysisResult:
        """Perform comprehensive repository analysis"""
        analysis_id = str(uuid.uuid4())
        start_time = time.time()
        
        logger.info("Starting repository analysis", 
                   analysis_id=analysis_id, 
                   repository_url=request.repository_url)
        
        try:
            # Clone repository to temporary directory
            with tempfile.TemporaryDirectory() as temp_dir:
                repo_path = await self._clone_repository(request.repository_url, temp_dir)
                
                # Analyze repository structure
                file_analysis = await self._analyze_files(repo_path, request.languages)
                
                # Generate dependency graph
                dependency_graph = await self._build_dependency_graph(repo_path, file_analysis)
                
                # Identify hotspots
                hotspots = await self._identify_hotspots(repo_path, file_analysis)
                
                # Security analysis
                security_findings = await self.security_service.scan_repository(repo_path)
                
                # Performance analysis (if dynamic testing requested)
                performance_metrics = {}
                if request.analysis_type in ['dynamic', 'full']:
                    performance_metrics = await self.performance_service.analyze_performance(repo_path)
                
                # Combine all findings
                all_findings = []
                all_findings.extend(file_analysis.get('findings', []))
                all_findings.extend(security_findings)
                
                # Calculate confidence scores
                confidence_scores = self._calculate_confidence_scores(all_findings)
                
                # Filter noise based on confidence
                filtered_findings = self._filter_findings(all_findings, confidence_scores)
                
                duration = time.time() - start_time
                
                result = AnalysisResult(
                    analysis_id=analysis_id,
                    status="completed",
                    findings=filtered_findings,
                    dependency_graph=dependency_graph,
                    hotspots=hotspots,
                    performance_metrics=performance_metrics,
                    confidence_scores=confidence_scores,
                    duration_seconds=int(duration),
                    summary={
                        "total_files": file_analysis.get('total_files', 0),
                        "total_lines": file_analysis.get('total_lines', 0),
                        "languages_detected": file_analysis.get('languages', []),
                        "critical_issues": len([f for f in filtered_findings if f.severity == 'critical']),
                        "high_issues": len([f for f in filtered_findings if f.severity == 'high']),
                        "medium_issues": len([f for f in filtered_findings if f.severity == 'medium']),
                        "low_issues": len([f for f in filtered_findings if f.severity == 'low'])
                    }
                )
                
                logger.info("Repository analysis completed", 
                           analysis_id=analysis_id, 
                           duration=duration,
                           findings_count=len(filtered_findings))
                
                # After result is created:
                redis_client.setex(f"analysis:{analysis_id}", 3600, _json.dumps(result.dict()))
                return result
                
        except Exception as e:
            logger.error("Repository analysis failed", 
                        analysis_id=analysis_id, 
                        error=str(e))
            
            return AnalysisResult(
                analysis_id=analysis_id,
                status="failed",
                error=str(e),
                duration_seconds=int(time.time() - start_time)
            )
    
    async def _clone_repository(self, repo_url: str, temp_dir: str) -> str:
        """Clone repository to temporary directory"""
        repo_path = os.path.join(temp_dir, "repo")
        
        # Handle different URL formats
        if repo_url.startswith(('http://', 'https://')):
            git.Repo.clone_from(repo_url, repo_path)
        else:
            # Assume it's a local path for demo purposes
            import shutil
            shutil.copytree(repo_url, repo_path)
        
        return repo_path
    
    async def _analyze_files(self, repo_path: str, target_languages: Optional[List[str]] = None) -> Dict:
        """Analyze individual files in the repository"""
        findings = []
        total_files = 0
        total_lines = 0
        languages_detected = set()
        
        # File extensions mapping
        extensions = {
            '.py': 'python',
            '.js': 'javascript',
            '.ts': 'typescript',
            '.jsx': 'javascript',
            '.tsx': 'typescript',
            '.java': 'java'
        }
        
        for root, dirs, files in os.walk(repo_path):
            # Skip common directories
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['node_modules', '__pycache__', 'target']]
            
            for file in files:
                file_path = os.path.join(root, file)
                relative_path = os.path.relpath(file_path, repo_path)
                
                # Get file extension
                ext = Path(file).suffix.lower()
                if ext not in extensions:
                    continue
                
                language = extensions[ext]
                if target_languages and language not in target_languages:
                    continue
                
                languages_detected.add(language)
                total_files += 1
                
                try:
                    # Read and analyze file
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    
                    lines = content.count('\n') + 1
                    total_lines += lines
                    
                    # Parse with Tree-sitter
                    if language in self.parsers:
                        file_findings = await self._analyze_single_file(
                            relative_path, content, language, lines
                        )
                        findings.extend(file_findings)
                
                except Exception as e:
                    logger.warning("Failed to analyze file", file=relative_path, error=str(e))
        
        return {
            'findings': findings,
            'total_files': total_files,
            'total_lines': total_lines,
            'languages': list(languages_detected)
        }
    
    async def _analyze_single_file(self, file_path: str, content: str, language: str, line_count: int) -> List[Finding]:
        """Analyze a single file for issues"""
        findings = []
        
        try:
            parser = self.parsers[language]
            tree = parser.parse(bytes(content, 'utf8'))
            
            # Basic complexity analysis
            if line_count > 500:
                findings.append(Finding(
                    finding_type="maintainability",
                    severity="medium",
                    confidence_score=0.8,
                    file_path=file_path,
                    line_start=1,
                    line_end=line_count,
                    title="Large file detected",
                    description=f"File has {line_count} lines, consider breaking it into smaller modules",
                    recommendation="Split large files into smaller, focused modules for better maintainability"
                ))
            
            # Language-specific analysis
            if language == 'python':
                findings.extend(self._analyze_python_file(file_path, content, tree))
            elif language in ['javascript', 'typescript']:
                findings.extend(self._analyze_javascript_file(file_path, content, tree))
            elif language == 'java':
                findings.extend(self._analyze_java_file(file_path, content, tree))
            
        except Exception as e:
            logger.warning("File analysis failed", file=file_path, error=str(e))
        
        return findings
    
    def _analyze_python_file(self, file_path: str, content: str, tree) -> List[Finding]:
        """Python-specific analysis"""
        findings = []
        lines = content.split('\n')
        
        # Check for common issues
        for i, line in enumerate(lines, 1):
            line_stripped = line.strip()
            
            # Check for print statements (should use logging)
            if line_stripped.startswith('print(') and not file_path.endswith('_test.py'):
                findings.append(Finding(
                    finding_type="style",
                    severity="low",
                    confidence_score=0.7,
                    file_path=file_path,
                    line_start=i,
                    line_end=i,
                    title="Print statement in production code",
                    description="Using print() for output in production code",
                    recommendation="Use logging module instead of print statements"
                ))
            
            # Check for TODO comments
            if 'TODO' in line_stripped.upper():
                findings.append(Finding(
                    finding_type="documentation",
                    severity="info",
                    confidence_score=0.9,
                    file_path=file_path,
                    line_start=i,
                    line_end=i,
                    title="TODO comment found",
                    description="Unresolved TODO comment",
                    recommendation="Address TODO items or convert to proper issue tracking"
                ))
        
        return findings
    
    def _analyze_javascript_file(self, file_path: str, content: str, tree) -> List[Finding]:
        """JavaScript/TypeScript-specific analysis"""
        findings = []
        lines = content.split('\n')
        
        for i, line in enumerate(lines, 1):
            line_stripped = line.strip()
            
            # Check for console.log
            if 'console.log(' in line_stripped:
                findings.append(Finding(
                    finding_type="style",
                    severity="low",
                    confidence_score=0.8,
                    file_path=file_path,
                    line_start=i,
                    line_end=i,
                    title="Console.log statement found",
                    description="Console.log should not be used in production",
                    recommendation="Use proper logging framework or remove debug statements"
                ))
            
            # Check for var usage (prefer let/const)
            if line_stripped.startswith('var '):
                findings.append(Finding(
                    finding_type="style",
                    severity="medium",
                    confidence_score=0.9,
                    file_path=file_path,
                    line_start=i,
                    line_end=i,
                    title="Use of 'var' keyword",
                    description="'var' has function scope, prefer 'let' or 'const'",
                    recommendation="Replace 'var' with 'let' or 'const' for block scoping"
                ))
        
        return findings
    
    def _analyze_java_file(self, file_path: str, content: str, tree) -> List[Finding]:
        """Java-specific analysis"""
        findings = []
        lines = content.split('\n')
        
        for i, line in enumerate(lines, 1):
            line_stripped = line.strip()
            
            # Check for System.out.println
            if 'System.out.println(' in line_stripped:
                findings.append(Finding(
                    finding_type="style",
                    severity="low",
                    confidence_score=0.8,
                    file_path=file_path,
                    line_start=i,
                    line_end=i,
                    title="System.out.println usage",
                    description="Direct console output in production code",
                    recommendation="Use logging framework like SLF4J instead"
                ))
        
        return findings
    
    async def _build_dependency_graph(self, repo_path: str, file_analysis: Dict) -> Dict:
        """Build repository dependency graph"""
        # Simplified dependency graph for demo
        return {
            "nodes": [
                {"id": "main", "type": "entry", "files": 1},
                {"id": "utils", "type": "utility", "files": 3},
                {"id": "services", "type": "service", "files": 5},
                {"id": "models", "type": "data", "files": 2}
            ],
            "edges": [
                {"source": "main", "target": "services", "weight": 3},
                {"source": "services", "target": "utils", "weight": 5},
                {"source": "services", "target": "models", "weight": 4}
            ]
        }
    
    async def _identify_hotspots(self, repo_path: str, file_analysis: Dict) -> List[Dict]:
        """Identify code hotspots based on complexity and change frequency"""
        # Mock hotspot data for demo
        return [
            {
                "file_path": "src/main.py",
                "complexity_score": 18,
                "change_frequency": 0.8,
                "issue_count": 5,
                "hotspot_score": 0.9,
                "recommendation": "High complexity and frequent changes indicate this file needs refactoring"
            },
            {
                "file_path": "src/services/analysis.py",
                "complexity_score": 15,
                "change_frequency": 0.6,
                "issue_count": 3,
                "hotspot_score": 0.7,
                "recommendation": "Consider breaking down large functions in this service"
            }
        ]
    
    def _calculate_confidence_scores(self, findings: List[Finding]) -> Dict:
        """Calculate ML-based confidence scores for findings"""
        # Simplified confidence scoring based on finding characteristics
        scores = {}
        
        for finding in findings:
            # Base confidence on finding type and severity
            base_confidence = {
                'critical': 0.95,
                'high': 0.85,
                'medium': 0.75,
                'low': 0.65,
                'info': 0.5
            }.get(finding.severity, 0.5)
            
            # Adjust based on finding type
            type_multiplier = {
                'security': 1.0,
                'performance': 0.9,
                'maintainability': 0.8,
                'style': 0.7,
                'documentation': 0.6
            }.get(finding.finding_type, 0.7)
            
            final_confidence = min(base_confidence * type_multiplier, 1.0)
            scores[f"{finding.file_path}:{finding.line_start}"] = final_confidence
        
        return scores
    
    def _filter_findings(self, findings: List[Finding], confidence_scores: Dict) -> List[Finding]:
        """Filter findings based on confidence scores and noise reduction"""
        filtered = []
        confidence_threshold = 0.5  # Configurable threshold
        
        for finding in findings:
            key = f"{finding.file_path}:{finding.line_start}"
            confidence = confidence_scores.get(key, finding.confidence_score or 0.5)
            
            if confidence >= confidence_threshold:
                # Update finding with calculated confidence
                finding.confidence_score = confidence
                filtered.append(finding)
        
        # Sort by severity and confidence
        severity_order = {'critical': 0, 'high': 1, 'medium': 2, 'low': 3, 'info': 4}
        filtered.sort(key=lambda f: (severity_order.get(f.severity, 5), -f.confidence_score))
        
        return filtered

    @staticmethod
    def get_cached_analysis(analysis_id: str):
        cached = redis_client.get(f"analysis:{analysis_id}")
        if cached:
            return _json.loads(cached)
        return None


@celery_app.task
def run_analysis_task(request_dict):
    """Celery task to run repository analysis in the background"""
    # Reconstruct AnalysisRequest from dict
    request = AnalysisRequest(**request_dict)
    service = AnalysisService()
    # Run analysis synchronously (Celery tasks are not async)
    import asyncio
    loop = asyncio.get_event_loop()
    result = loop.run_until_complete(service.analyze_repository(request))
    # Convert result to dict for serialization
    return result.dict()