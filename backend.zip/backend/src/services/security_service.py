"""
Security analysis service for vulnerability detection
"""
import json
import os
import re
from typing import Dict, List

import structlog

from src.models.analysis import Finding

logger = structlog.get_logger()


class SecurityService:
    """Service for security vulnerability detection"""
    
    def __init__(self):
        # Common vulnerability patterns
        self.vulnerability_patterns = {
            'sql_injection': {
                'patterns': [
                    r'execute\s*\(\s*["\'].*\+.*["\']',  # String concatenation in SQL
                    r'query\s*\(\s*["\'].*\+.*["\']',
                    r'SELECT.*\+.*FROM',
                    r'INSERT.*\+.*VALUES'
                ],
                'severity': 'critical',
                'cve_example': 'CVE-2023-1234'
            },
            'xss': {
                'patterns': [
                    r'innerHTML\s*=\s*.*\+',  # Direct innerHTML assignment
                    r'document\.write\s*\(',
                    r'eval\s*\(',
                    r'dangerouslySetInnerHTML'
                ],
                'severity': 'high',
                'cve_example': 'CVE-2023-5678'
            },
            'hardcoded_secrets': {
                'patterns': [
                    r'password\s*=\s*["\'][^"\']{8,}["\']',
                    r'api_key\s*=\s*["\'][^"\']{20,}["\']',
                    r'secret\s*=\s*["\'][^"\']{16,}["\']',
                    r'token\s*=\s*["\'][^"\']{20,}["\']'
                ],
                'severity': 'high',
                'cve_example': None
            },
            'weak_crypto': {
                'patterns': [
                    r'md5\s*\(',
                    r'sha1\s*\(',
                    r'DES\s*\(',
                    r'RC4\s*\('
                ],
                'severity': 'medium',
                'cve_example': 'CVE-2023-9012'
            },
            'path_traversal': {
                'patterns': [
                    r'open\s*\(\s*.*\+.*\)',
                    r'file\s*\(\s*.*\+.*\)',
                    r'readFile\s*\(\s*.*\+.*\)',
                    r'\.\./'
                ],
                'severity': 'high',
                'cve_example': 'CVE-2023-3456'
            }
        }
    
    async def scan_repository(self, repo_path: str) -> List[Finding]:
        """Scan repository for security vulnerabilities"""
        findings = []
        
        logger.info("Starting security scan", repo_path=repo_path)
        
        # Scan all relevant files
        for root, dirs, files in os.walk(repo_path):
            # Skip common directories
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['node_modules', '__pycache__', 'target']]
            
            for file in files:
                if self._should_scan_file(file):
                    file_path = os.path.join(root, file)
                    relative_path = os.path.relpath(file_path, repo_path)
                    
                    try:
                        file_findings = await self._scan_file(file_path, relative_path)
                        findings.extend(file_findings)
                    except Exception as e:
                        logger.warning("Failed to scan file", file=relative_path, error=str(e))
        
        logger.info("Security scan completed", findings_count=len(findings))
        return findings
    
    def _should_scan_file(self, filename: str) -> bool:
        """Check if file should be scanned for security issues"""
        scan_extensions = {'.py', '.js', '.ts', '.jsx', '.tsx', '.java', '.php', '.rb', '.go', '.cs'}
        return any(filename.endswith(ext) for ext in scan_extensions)
    
    async def _scan_file(self, file_path: str, relative_path: str) -> List[Finding]:
        """Scan individual file for security vulnerabilities"""
        findings = []
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            lines = content.split('\n')
            
            # Check each vulnerability pattern
            for vuln_type, vuln_config in self.vulnerability_patterns.items():
                for pattern in vuln_config['patterns']:
                    findings.extend(
                        self._find_pattern_matches(
                            pattern, lines, relative_path, vuln_type, vuln_config
                        )
                    )
            
            # Additional context-specific checks
            findings.extend(self._check_dependencies(relative_path, content))
            findings.extend(self._check_configuration_files(relative_path, content))
            
        except Exception as e:
            logger.error("File scan failed", file=relative_path, error=str(e))
        
        return findings
    
    def _find_pattern_matches(
        self, 
        pattern: str, 
        lines: List[str], 
        file_path: str, 
        vuln_type: str, 
        config: Dict
    ) -> List[Finding]:
        """Find matches for a specific vulnerability pattern"""
        findings = []
        
        for line_num, line in enumerate(lines, 1):
            if re.search(pattern, line, re.IGNORECASE):
                finding = Finding(
                    finding_type="security",
                    severity=config['severity'],
                    confidence_score=0.8,  # Base confidence for pattern matching
                    file_path=file_path,
                    line_start=line_num,
                    line_end=line_num,
                    title=self._get_vulnerability_title(vuln_type),
                    description=self._get_vulnerability_description(vuln_type, line.strip()),
                    recommendation=self._get_vulnerability_recommendation(vuln_type),
                    cve_id=config.get('cve_example')
                )
                findings.append(finding)
        
        return findings
    
    def _get_vulnerability_title(self, vuln_type: str) -> str:
        """Get human-readable title for vulnerability type"""
        titles = {
            'sql_injection': 'Potential SQL Injection Vulnerability',
            'xss': 'Cross-Site Scripting (XSS) Risk',
            'hardcoded_secrets': 'Hardcoded Secret Detected',
            'weak_crypto': 'Weak Cryptographic Algorithm',
            'path_traversal': 'Path Traversal Vulnerability'
        }
        return titles.get(vuln_type, 'Security Issue Detected')
    
    def _get_vulnerability_description(self, vuln_type: str, code_line: str) -> str:
        """Get detailed description for vulnerability"""
        descriptions = {
            'sql_injection': f'Potential SQL injection vulnerability detected. The code appears to concatenate user input directly into SQL queries: {code_line[:100]}...',
            'xss': f'Cross-site scripting vulnerability detected. User input may be rendered without proper sanitization: {code_line[:100]}...',
            'hardcoded_secrets': f'Hardcoded secret or credential detected in source code: {code_line[:50]}...',
            'weak_crypto': f'Weak cryptographic algorithm detected. This algorithm is considered insecure: {code_line[:100]}...',
            'path_traversal': f'Potential path traversal vulnerability. File operations may allow access to unauthorized files: {code_line[:100]}...'
        }
        return descriptions.get(vuln_type, f'Security issue detected in: {code_line[:100]}...')
    
    def _get_vulnerability_recommendation(self, vuln_type: str) -> str:
        """Get remediation recommendation for vulnerability"""
        recommendations = {
            'sql_injection': 'Use parameterized queries or prepared statements instead of string concatenation. Validate and sanitize all user inputs.',
            'xss': 'Sanitize user input before rendering. Use content security policy (CSP) headers and avoid direct DOM manipulation with user data.',
            'hardcoded_secrets': 'Move secrets to environment variables or secure configuration files. Use secret management systems for production.',
            'weak_crypto': 'Replace with strong cryptographic algorithms like AES-256, SHA-256, or bcrypt for password hashing.',
            'path_traversal': 'Validate file paths and use allowlists for permitted files. Avoid direct user input in file operations.'
        }
        return recommendations.get(vuln_type, 'Review and remediate this security issue following security best practices.')
    
    def _check_dependencies(self, file_path: str, content: str) -> List[Finding]:
        """Check for vulnerable dependencies"""
        findings = []
        
        # Check package.json for known vulnerable packages
        if file_path.endswith('package.json'):
            try:
                package_data = json.loads(content)
                dependencies = {**package_data.get('dependencies', {}), **package_data.get('devDependencies', {})}
                
                # Mock vulnerable packages (in real implementation, use vulnerability database)
                vulnerable_packages = {
                    'lodash': {'versions': ['<4.17.21'], 'cve': 'CVE-2021-23337'},
                    'express': {'versions': ['<4.18.2'], 'cve': 'CVE-2022-24999'},
                    'axios': {'versions': ['<0.21.2'], 'cve': 'CVE-2021-3749'}
                }
                
                for pkg_name, version in dependencies.items():
                    if pkg_name in vulnerable_packages:
                        findings.append(Finding(
                            finding_type="security",
                            severity="medium",
                            confidence_score=0.9,
                            file_path=file_path,
                            line_start=1,
                            line_end=1,
                            title=f"Vulnerable dependency: {pkg_name}",
                            description=f"Package {pkg_name} version {version} has known security vulnerabilities",
                            recommendation=f"Update {pkg_name} to the latest secure version",
                            cve_id=vulnerable_packages[pkg_name]['cve']
                        ))
            except json.JSONDecodeError:
                pass
        
        # Check requirements.txt for Python packages
        elif file_path.endswith('requirements.txt'):
            lines = content.split('\n')
            vulnerable_python_packages = {
                'django': {'versions': ['<3.2.15'], 'cve': 'CVE-2022-34265'},
                'flask': {'versions': ['<2.2.2'], 'cve': 'CVE-2023-30861'},
                'requests': {'versions': ['<2.28.0'], 'cve': 'CVE-2023-32681'}
            }
            
            for line_num, line in enumerate(lines, 1):
                line = line.strip()
                if '==' in line:
                    pkg_name = line.split('==')[0].strip()
                    if pkg_name in vulnerable_python_packages:
                        findings.append(Finding(
                            finding_type="security",
                            severity="medium",
                            confidence_score=0.9,
                            file_path=file_path,
                            line_start=line_num,
                            line_end=line_num,
                            title=f"Vulnerable Python package: {pkg_name}",
                            description=f"Package {pkg_name} has known security vulnerabilities",
                            recommendation=f"Update {pkg_name} to the latest secure version",
                            cve_id=vulnerable_python_packages[pkg_name]['cve']
                        ))
        
        return findings
    
    def _check_configuration_files(self, file_path: str, content: str) -> List[Finding]:
        """Check configuration files for security issues"""
        findings = []
        
        # Check for insecure configurations
        if file_path.endswith(('.env', '.config', '.ini', '.yaml', '.yml')):
            lines = content.split('\n')
            
            for line_num, line in enumerate(lines, 1):
                line_lower = line.lower().strip()
                
                # Check for debug mode in production
                if 'debug' in line_lower and ('true' in line_lower or '1' in line_lower):
                    findings.append(Finding(
                        finding_type="security",
                        severity="medium",
                        confidence_score=0.7,
                        file_path=file_path,
                        line_start=line_num,
                        line_end=line_num,
                        title="Debug mode enabled",
                        description="Debug mode should be disabled in production environments",
                        recommendation="Set debug mode to false in production configurations"
                    ))
                
                # Check for insecure protocols
                if any(protocol in line_lower for protocol in ['http://', 'ftp://', 'telnet://']):
                    findings.append(Finding(
                        finding_type="security",
                        severity="medium",
                        confidence_score=0.8,
                        file_path=file_path,
                        line_start=line_num,
                        line_end=line_num,
                        title="Insecure protocol detected",
                        description="Using insecure protocol that transmits data in plaintext",
                        recommendation="Use secure protocols (HTTPS, SFTP, SSH) instead"
                    ))
        
        return findings