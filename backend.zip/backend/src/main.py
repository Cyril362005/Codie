"""
Codie AI Code Review Assistant - Main FastAPI Application
"""
import asyncio
import logging
from contextlib import asynccontextmanager
from typing import AsyncGenerator

import structlog
import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from prometheus_client import make_asgi_app

from src.api.routes import analysis, auth, chat, repositories, security
from src.core.config import get_settings
from src.core.database import init_db
from src.core.websocket import ConnectionManager
from src.services.analysis_service import AnalysisService
from src.services.ai_service import AIService

# Configure structured logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

settings = get_settings()


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan manager"""
    logger.info("Starting Codie backend server")
    
    # Initialize database
    await init_db()
    
    # Initialize services
    app.state.analysis_service = AnalysisService()
    app.state.ai_service = AIService()
    app.state.connection_manager = ConnectionManager()
    
    logger.info("Backend services initialized")
    
    yield
    
    logger.info("Shutting down Codie backend server")


# Create FastAPI application
app = FastAPI(
    title="Codie AI Code Review Assistant",
    description="AI-powered code review platform with repository-wide intelligence",
    version="1.0.0",
    docs_url="/api/docs" if settings.DEBUG else None,
    redoc_url="/api/redoc" if settings.DEBUG else None,
    lifespan=lifespan
)

# Add middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(
    TrustedHostMiddleware,
    allowed_hosts=settings.ALLOWED_HOSTS
)

# Add Prometheus metrics
metrics_app = make_asgi_app()
app.mount("/metrics", metrics_app)

# Include API routes
app.include_router(auth.router, prefix="/api/v1/auth", tags=["authentication"])
app.include_router(analysis.router, prefix="/api/v1/analysis", tags=["analysis"])
app.include_router(chat.router, prefix="/api/v1/chat", tags=["chat"])
app.include_router(repositories.router, prefix="/api/v1/repositories", tags=["repositories"])
app.include_router(security.router, prefix="/api/v1/security", tags=["security"])


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "timestamp": structlog.processors.TimeStamper(fmt="iso")._stamper()
    }


@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    """WebSocket endpoint for real-time updates"""
    connection_manager = app.state.connection_manager
    await connection_manager.connect(websocket, client_id)
    
    try:
        while True:
            data = await websocket.receive_text()
            logger.info("WebSocket message received", client_id=client_id, data=data)
            
            # Echo message back (can be extended for specific functionality)
            await connection_manager.send_personal_message(f"Echo: {data}", websocket)
            
    except WebSocketDisconnect:
        connection_manager.disconnect(websocket, client_id)
        logger.info("WebSocket client disconnected", client_id=client_id)


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
        log_config=None,  # Use structlog instead
        access_log=False
    )