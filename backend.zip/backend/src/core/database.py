"""
Database configuration and models
"""
import uuid
from datetime import datetime
from typing import Optional

from sqlalchemy import (
    Boolean, Column, DateTime, Enum, Float, Integer, 
    String, Text, JSON, ForeignKey, create_engine
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker
from sqlalchemy.sql import func

from src.core.config import get_settings

settings = get_settings()

# Create async engine
engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,
    future=True
)

# Create session factory
async_session = sessionmaker(
    engine, class_=AsyncSession, expire_on_commit=False
)

Base = declarative_base()


class User(Base):
    """User model"""
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    hashed_password = Column(String(255), nullable=False)
    full_name = Column(String(255))
    is_active = Column(Boolean, default=True)
    is_superuser = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    repositories = relationship("Repository", back_populates="owner")
    analyses = relationship("Analysis", back_populates="user")


class Repository(Base):
    """Repository model"""
    __tablename__ = "repositories"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    url = Column(Text)
    description = Column(Text)
    languages = Column(JSON)  # List of programming languages
    default_branch = Column(String(100), default="main")
    is_private = Column(Boolean, default=False)
    owner_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Configuration
    style_preferences = Column(JSON)
    analysis_settings = Column(JSON)
    
    # Relationships
    owner = relationship("User", back_populates="repositories")
    analyses = relationship("Analysis", back_populates="repository")


class Analysis(Base):
    """Analysis model"""
    __tablename__ = "analyses"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    repository_id = Column(UUID(as_uuid=True), ForeignKey("repositories.id"), nullable=False)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    
    # Analysis metadata
    commit_hash = Column(String(40))
    branch = Column(String(100))
    analysis_type = Column(Enum("static", "dynamic", "security", "full", name="analysis_type"))
    status = Column(Enum("pending", "running", "completed", "failed", name="analysis_status"))
    
    # Results
    findings = Column(JSON)  # List of findings
    metrics = Column(JSON)   # Performance and quality metrics
    dependency_graph = Column(JSON)  # Repository dependency information
    confidence_scores = Column(JSON)  # ML confidence scores
    
    # Timing
    started_at = Column(DateTime(timezone=True))
    completed_at = Column(DateTime(timezone=True))
    duration_seconds = Column(Integer)
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    repository = relationship("Repository", back_populates="analyses")
    user = relationship("User", back_populates="analyses")
    findings_detail = relationship("Finding", back_populates="analysis")


class Finding(Base):
    """Individual finding from analysis"""
    __tablename__ = "findings"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    analysis_id = Column(UUID(as_uuid=True), ForeignKey("analyses.id"), nullable=False)
    
    # Finding details
    finding_type = Column(Enum(
        "security", "performance", "style", "maintainability", 
        "testing", "architecture", "documentation", name="finding_type"
    ))
    severity = Column(Enum("critical", "high", "medium", "low", "info", name="severity"))
    confidence_score = Column(Float)  # 0.0 to 1.0
    
    # Location
    file_path = Column(Text, nullable=False)
    line_start = Column(Integer)
    line_end = Column(Integer)
    column_start = Column(Integer)
    column_end = Column(Integer)
    
    # Content
    title = Column(String(500), nullable=False)
    description = Column(Text)
    recommendation = Column(Text)
    code_suggestion = Column(Text)
    
    # External references
    cve_id = Column(String(50))  # For security findings
    rule_id = Column(String(100))  # Internal rule identifier
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    analysis = relationship("Analysis", back_populates="findings_detail")


class ChatSession(Base):
    """Chat session for AI interactions"""
    __tablename__ = "chat_sessions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False)
    analysis_id = Column(UUID(as_uuid=True), ForeignKey("analyses.id"))
    
    # Session data
    messages = Column(JSON)  # List of chat messages
    context = Column(JSON)   # Additional context for AI
    
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())


async def init_db():
    """Initialize database tables"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def get_db() -> AsyncSession:
    """Get database session"""
    async with async_session() as session:
        try:
            yield session
        finally:
            await session.close()