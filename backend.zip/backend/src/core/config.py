"""
Configuration management for Codie backend
"""
from functools import lru_cache
from typing import List

from pydantic import BaseSettings


class Settings(BaseSettings):
    """Application settings"""
    
    # Application
    DEBUG: bool = True
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ALLOWED_ORIGINS: List[str] = ["http://localhost:5173", "http://localhost:3000"]
    ALLOWED_HOSTS: List[str] = ["localhost", "127.0.0.1", "*"]
    
    # Database
    DATABASE_URL: str = "postgresql+asyncpg://codie:password@localhost:5432/codie"
    REDIS_URL: str = "redis://localhost:6380/0"
    
    # AI Services
    OPENAI_API_KEY: str = ""
    OPENAI_MODEL: str = "gpt-4"
    
    # External APIs
    SNYK_API_KEY: str = ""
    GITHUB_TOKEN: str = ""
    
    # Security
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    # Analysis
    MAX_FILE_SIZE_MB: int = 10
    MAX_REPOSITORY_SIZE_MB: int = 500
    ANALYSIS_TIMEOUT_SECONDS: int = 300
    
    # Background Tasks
    CELERY_BROKER_URL: str = "redis://localhost:6380/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6380/2"
    
    class Config:
        env_file = ".env"
        case_sensitive = True


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance"""
    return Settings()