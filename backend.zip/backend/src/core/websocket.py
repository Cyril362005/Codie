"""
WebSocket connection manager for real-time updates
"""
from typing import Dict, List
from fastapi import WebSocket
import structlog

logger = structlog.get_logger()


class ConnectionManager:
    """Manages WebSocket connections"""
    
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        self.client_analysis: Dict[str, str] = {}  # client_id -> analysis_id
    
    async def connect(self, websocket: WebSocket, client_id: str):
        """Accept new WebSocket connection"""
        await websocket.accept()
        self.active_connections[client_id] = websocket
        logger.info("WebSocket connection established", client_id=client_id)
    
    def disconnect(self, websocket: WebSocket, client_id: str):
        """Remove WebSocket connection"""
        if client_id in self.active_connections:
            del self.active_connections[client_id]
        if client_id in self.client_analysis:
            del self.client_analysis[client_id]
        logger.info("WebSocket connection closed", client_id=client_id)
    
    async def send_personal_message(self, message: str, websocket: WebSocket):
        """Send message to specific WebSocket"""
        await websocket.send_text(message)
    
    async def send_to_client(self, client_id: str, message: dict):
        """Send message to specific client"""
        if client_id in self.active_connections:
            websocket = self.active_connections[client_id]
            await websocket.send_json(message)
    
    async def broadcast_analysis_update(self, analysis_id: str, update: dict):
        """Broadcast analysis update to all connected clients following this analysis"""
        for client_id, websocket in self.active_connections.items():
            if self.client_analysis.get(client_id) == analysis_id:
                await websocket.send_json({
                    "type": "analysis_update",
                    "analysis_id": analysis_id,
                    "data": update
                })
    
    def subscribe_to_analysis(self, client_id: str, analysis_id: str):
        """Subscribe client to analysis updates"""
        self.client_analysis[client_id] = analysis_id
        logger.info("Client subscribed to analysis", client_id=client_id, analysis_id=analysis_id)