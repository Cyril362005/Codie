"""
Security analysis API routes
"""
from typing import List, Optional

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.database import get_db
from src.api.routes.auth import get_current_user, User

router = APIRouter()


class SecurityFinding(BaseModel):
    id: str
    severity: str  # critical, high, medium, low
    title: str
    description: str
    file_path: str
    line_number: int
    cve_id: Optional[str]
    confidence: float
    remediation: str
    status: str  # open, in_progress, resolved
    created_at: str


class SecuritySummary(BaseModel):
    total_findings: int
    critical_count: int
    high_count: int
    medium_count: int
    low_count: int
    resolved_count: int
    avg_confidence: float
    last_scan_at: str


class VulnerabilityDetails(BaseModel):
    cve_id: str
    title: str
    description: str
    severity: str
    cvss_score: float
    published_date: str
    affected_versions: List[str]
    patched_versions: List[str]
    references: List[str]


@router.get("/summary", response_model=SecuritySummary)
async def get_security_summary(
    repository_id: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get security analysis summary"""
    return SecuritySummary(
        total_findings=15,
        critical_count=2,
        high_count=4,
        medium_count=6,
        low_count=3,
        resolved_count=8,
        avg_confidence=0.87,
        last_scan_at="2024-01-01T12:00:00Z"
    )


@router.get("/findings", response_model=List[SecurityFinding])
async def list_security_findings(
    repository_id: Optional[str] = Query(None),
    severity: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    skip: int = Query(0, ge=0),
    limit: int = Query(10, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """List security findings"""
    # Mock data for demo
    return [
        SecurityFinding(
            id="finding-1",
            severity="critical",
            title="SQL Injection Vulnerability",
            description="User input is directly concatenated into SQL query without proper validation",
            file_path="src/database.py",
            line_number=42,
            cve_id="CVE-2023-1234",
            confidence=0.95,
            remediation="Use parameterized queries or prepared statements",
            status="open",
            created_at="2024-01-01T10:00:00Z"
        ),
        SecurityFinding(
            id="finding-2",
            severity="high",
            title="Cross-Site Scripting (XSS)",
            description="User input is rendered without proper sanitization",
            file_path="src/templates/user_profile.html",
            line_number=28,
            cve_id="CVE-2023-5678",
            confidence=0.88,
            remediation="Sanitize user input before rendering or use content security policy",
            status="in_progress",
            created_at="2024-01-01T10:15:00Z"
        ),
        SecurityFinding(
            id="finding-3",
            severity="medium",
            title="Insecure Dependencies",
            description="Using outdated version of Express.js with known vulnerabilities",
            file_path="package.json",
            line_number=15,
            cve_id=None,
            confidence=0.92,
            remediation="Update Express.js to version 4.18.2 or later",
            status="open",
            created_at="2024-01-01T10:30:00Z"
        )
    ]


@router.get("/findings/{finding_id}", response_model=SecurityFinding)
async def get_security_finding(
    finding_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get security finding details"""
    return SecurityFinding(
        id=finding_id,
        severity="critical",
        title="SQL Injection Vulnerability",
        description="User input is directly concatenated into SQL query without proper validation or parameterization",
        file_path="src/database.py",
        line_number=42,
        cve_id="CVE-2023-1234",
        confidence=0.95,
        remediation="Use parameterized queries or prepared statements. Validate and sanitize all user inputs.",
        status="open",
        created_at="2024-01-01T10:00:00Z"
    )


@router.put("/findings/{finding_id}/status")
async def update_finding_status(
    finding_id: str,
    status: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update security finding status"""
    return {"message": f"Finding {finding_id} status updated to {status}"}


@router.get("/cve/{cve_id}", response_model=VulnerabilityDetails)
async def get_cve_details(
    cve_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get CVE vulnerability details"""
    return VulnerabilityDetails(
        cve_id=cve_id,
        title="SQL Injection in Database Query Builder",
        description="A SQL injection vulnerability exists in the query builder component when user input is not properly sanitized before being used in database queries.",
        severity="critical",
        cvss_score=9.8,
        published_date="2023-01-15",
        affected_versions=["1.0.0", "1.1.0", "1.2.0"],
        patched_versions=["1.2.1", "1.3.0"],
        references=[
            "https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-1234",
            "https://nvd.nist.gov/vuln/detail/CVE-2023-1234"
        ]
    )


@router.post("/scan")
async def start_security_scan(
    repository_id: str,
    scan_type: str = Query("full", regex="^(quick|full|dependencies)$"),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Start security scan"""
    return {
        "scan_id": "scan-123",
        "status": "started",
        "repository_id": repository_id,
        "scan_type": scan_type,
        "estimated_duration": "5 minutes"
    }


@router.get("/scan/{scan_id}/status")
async def get_scan_status(
    scan_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get security scan status"""
    return {
        "scan_id": scan_id,
        "status": "completed",
        "progress": 100,
        "findings_found": 15,
        "duration_seconds": 287,
        "completed_at": "2024-01-01T12:05:00Z"
    }


@router.get("/recommendations")
async def get_security_recommendations(
    repository_id: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get security recommendations"""
    return [
        {
            "type": "immediate_action",
            "priority": "critical",
            "title": "Address SQL Injection Vulnerability",
            "description": "Critical SQL injection vulnerability requires immediate attention",
            "action": "Implement parameterized queries in src/database.py:42"
        },
        {
            "type": "best_practice",
            "priority": "high",
            "title": "Implement Content Security Policy",
            "description": "Add CSP headers to prevent XSS attacks",
            "action": "Configure CSP headers in web server or application middleware"
        },
        {
            "type": "dependency_update",
            "priority": "medium",
            "title": "Update Vulnerable Dependencies",
            "description": "3 dependencies have known security vulnerabilities",
            "action": "Run 'npm audit fix' or update packages manually"
        }
    ]