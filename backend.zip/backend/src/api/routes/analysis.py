"""
Analysis API routes
"""
import uuid
from typing import List, Optional

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query
from sqlalchemy.ext.asyncio import AsyncSession
from celery.result import AsyncResult

from src.core.database import get_db
from src.core.celery_app import celery_app
from src.models.analysis import AnalysisRequest, AnalysisResult, AnalysisStatus
from src.services.analysis_service import AnalysisService

router = APIRouter()


@router.post("/", response_model=dict)
async def create_analysis(
    request: AnalysisRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db)
):
    """Start a new code analysis as a background Celery task"""
    task = celery_app.send_task("src.services.analysis_service.run_analysis_task", args=[request.dict()])
    return {"task_id": task.id}


@router.get("/{analysis_id}", response_model=AnalysisResult)
async def get_analysis(
    analysis_id: str,
    db: AsyncSession = Depends(get_db)
):
    """Get analysis results by ID, using Redis cache if available"""
    cached = AnalysisService.get_cached_analysis(analysis_id)
    if cached:
        return cached
    # In a real implementation, this would fetch from database
    # For demo, return mock data
    return AnalysisResult(
        analysis_id=analysis_id,
        status="completed",
        findings=[],
        duration_seconds=45,
        summary={
            "total_files": 25,
            "total_lines": 3420,
            "languages_detected": ["python", "javascript"],
            "critical_issues": 2,
            "high_issues": 5,
            "medium_issues": 12,
            "low_issues": 8
        }
    )


@router.get("/{analysis_id}/status", response_model=AnalysisStatus)
async def get_analysis_status(
    analysis_id: str,
    db: AsyncSession = Depends(get_db)
):
    """Get analysis status"""
    return AnalysisStatus(
        analysis_id=analysis_id,
        status="completed",
        progress=1.0,
        current_step="Analysis complete",
        message="Analysis completed successfully"
    )


@router.get("/", response_model=List[AnalysisResult])
async def list_analyses(
    skip: int = Query(0, ge=0),
    limit: int = Query(10, ge=1, le=100),
    status: Optional[str] = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """List user's analyses"""
    # Mock data for demo
    return [
        AnalysisResult(
            analysis_id=str(uuid.uuid4()),
            status="completed",
            findings=[],
            duration_seconds=32,
            summary={
                "total_files": 15,
                "total_lines": 2100,
                "languages_detected": ["python"],
                "critical_issues": 1,
                "high_issues": 3,
                "medium_issues": 7,
                "low_issues": 4
            }
        )
    ]


@router.delete("/{analysis_id}")
async def delete_analysis(
    analysis_id: str,
    db: AsyncSession = Depends(get_db)
):
    """Delete an analysis"""
    return {"message": "Analysis deleted successfully"}


@router.post("/{analysis_id}/export")
async def export_analysis(
    analysis_id: str,
    format: str = Query("pdf", regex="^(pdf|markdown|json)$"),
    db: AsyncSession = Depends(get_db)
):
    """Export analysis results"""
    # In real implementation, generate and return file
    return {
        "download_url": f"/api/v1/analysis/{analysis_id}/download/{format}",
        "expires_at": "2024-01-01T12:00:00Z"
    }


@router.get("/task/{task_id}")
async def get_analysis_task_status(task_id: str):
    """Get Celery task status and result by task_id"""
    result = AsyncResult(task_id)
    response = {
        "task_id": task_id,
        "status": result.status,
        "result": result.result if result.ready() else None
    }
    return response