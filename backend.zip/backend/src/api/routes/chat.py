"""
Chat API routes for AI interactions
"""
from typing import List

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.database import get_db
from src.models.chat import ChatRequest, ChatResponse, ExplanationRequest, RefactoringRequest
from src.services.ai_service import AIService

router = APIRouter()


@router.post("/", response_model=ChatResponse)
async def chat_with_ai(
    request: ChatRequest,
    db: AsyncSession = Depends(get_db)
):
    """Send message to AI assistant"""
    ai_service = AIService()
    
    # Build context from request
    context = request.context or {}
    if request.analysis_id:
        context['analysis_id'] = request.analysis_id
    
    response = await ai_service.chat_about_code(
        message=request.message,
        context=context,
        conversation_history=request.conversation_history
    )
    
    return response


@router.post("/explain", response_model=str)
async def explain_finding(
    request: ExplanationRequest,
    db: AsyncSession = Depends(get_db)
):
    """Get detailed explanation for a finding"""
    ai_service = AIService()
    
    # Mock finding data (in real implementation, fetch from database)
    finding = {
        "finding_type": "security",
        "severity": "high",
        "title": "SQL Injection Vulnerability",
        "description": "User input concatenated directly into SQL query",
        "file_path": "src/database.py",
        "line_start": 42
    }
    
    explanation = await ai_service.explain_finding(finding, request.code_context)
    return explanation


@router.post("/refactor")
async def suggest_refactoring(
    request: RefactoringRequest,
    db: AsyncSession = Depends(get_db)
):
    """Get refactoring suggestions for code"""
    ai_service = AIService()
    
    suggestions = await ai_service.suggest_refactoring(
        code=request.code,
        language=request.language,
        issues=request.issues
    )
    
    return suggestions


@router.get("/sessions")
async def list_chat_sessions(
    analysis_id: str = None,
    db: AsyncSession = Depends(get_db)
):
    """List user's chat sessions"""
    # Mock data for demo
    return [
        {
            "id": "session-1",
            "analysis_id": analysis_id,
            "created_at": "2024-01-01T10:00:00Z",
            "message_count": 5,
            "last_message": "Can you explain the security vulnerability on line 42?"
        }
    ]


@router.get("/sessions/{session_id}/messages")
async def get_session_messages(
    session_id: str,
    db: AsyncSession = Depends(get_db)
):
    """Get messages from a chat session"""
    # Mock conversation history
    return [
        {
            "id": "msg-1",
            "content": "Can you explain the security vulnerability on line 42?",
            "is_user": True,
            "timestamp": "2024-01-01T10:00:00Z"
        },
        {
            "id": "msg-2",
            "content": "The security issue on line 42 is a potential SQL injection vulnerability...",
            "is_user": False,
            "timestamp": "2024-01-01T10:00:05Z"
        }
    ]