"""
Repository management API routes
"""
import uuid
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from src.core.database import get_db
from src.api.routes.auth import get_current_user, User

router = APIRouter()


class RepositoryCreate(BaseModel):
    name: str
    url: Optional[str] = None
    description: Optional[str] = None
    languages: Optional[List[str]] = None
    is_private: bool = False


class RepositoryUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    languages: Optional[List[str]] = None
    style_preferences: Optional[dict] = None
    analysis_settings: Optional[dict] = None


class Repository(BaseModel):
    id: str
    name: str
    url: Optional[str]
    description: Optional[str]
    languages: Optional[List[str]]
    default_branch: str
    is_private: bool
    created_at: str
    updated_at: Optional[str]
    
    # Configuration
    style_preferences: Optional[dict]
    analysis_settings: Optional[dict]
    
    # Statistics
    total_analyses: int
    last_analysis_at: Optional[str]


@router.post("/", response_model=Repository)
async def create_repository(
    repo_data: RepositoryCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Create a new repository"""
    # In real implementation, save to database
    # For demo, return mock repository
    
    repo_id = str(uuid.uuid4())
    
    return Repository(
        id=repo_id,
        name=repo_data.name,
        url=repo_data.url,
        description=repo_data.description,
        languages=repo_data.languages or [],
        default_branch="main",
        is_private=repo_data.is_private,
        created_at="2024-01-01T10:00:00Z",
        updated_at=None,
        style_preferences={},
        analysis_settings={},
        total_analyses=0,
        last_analysis_at=None
    )


@router.get("/", response_model=List[Repository])
async def list_repositories(
    skip: int = Query(0, ge=0),
    limit: int = Query(10, ge=1, le=100),
    search: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """List user's repositories"""
    # Mock data for demo
    return [
        Repository(
            id="repo-1",
            name="frontend-dashboard",
            url="https://github.com/user/frontend-dashboard",
            description="React dashboard application",
            languages=["javascript", "typescript"],
            default_branch="main",
            is_private=False,
            created_at="2024-01-01T10:00:00Z",
            updated_at="2024-01-01T12:00:00Z",
            style_preferences={"indent_size": 2, "quote_style": "single"},
            analysis_settings={"enable_security": True, "enable_performance": True},
            total_analyses=5,
            last_analysis_at="2024-01-01T12:00:00Z"
        ),
        Repository(
            id="repo-2",
            name="api-backend",
            url="https://github.com/user/api-backend",
            description="Python FastAPI backend",
            languages=["python"],
            default_branch="main",
            is_private=True,
            created_at="2024-01-01T09:00:00Z",
            updated_at="2024-01-01T11:30:00Z",
            style_preferences={"line_length": 88, "quote_style": "double"},
            analysis_settings={"enable_security": True, "enable_performance": False},
            total_analyses=3,
            last_analysis_at="2024-01-01T11:30:00Z"
        )
    ]


@router.get("/{repository_id}", response_model=Repository)
async def get_repository(
    repository_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get repository by ID"""
    # Mock data for demo
    return Repository(
        id=repository_id,
        name="example-repo",
        url="https://github.com/user/example-repo",
        description="Example repository",
        languages=["python", "javascript"],
        default_branch="main",
        is_private=False,
        created_at="2024-01-01T10:00:00Z",
        updated_at="2024-01-01T12:00:00Z",
        style_preferences={"indent_size": 4, "quote_style": "double"},
        analysis_settings={"enable_security": True, "enable_performance": True},
        total_analyses=8,
        last_analysis_at="2024-01-01T12:00:00Z"
    )


@router.put("/{repository_id}", response_model=Repository)
async def update_repository(
    repository_id: str,
    repo_data: RepositoryUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update repository"""
    # In real implementation, update in database
    # For demo, return updated mock data
    
    return Repository(
        id=repository_id,
        name=repo_data.name or "updated-repo",
        url="https://github.com/user/updated-repo",
        description=repo_data.description or "Updated repository",
        languages=repo_data.languages or ["python"],
        default_branch="main",
        is_private=False,
        created_at="2024-01-01T10:00:00Z",
        updated_at="2024-01-01T13:00:00Z",
        style_preferences=repo_data.style_preferences or {},
        analysis_settings=repo_data.analysis_settings or {},
        total_analyses=8,
        last_analysis_at="2024-01-01T12:00:00Z"
    )


@router.delete("/{repository_id}")
async def delete_repository(
    repository_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Delete repository"""
    return {"message": "Repository deleted successfully"}


@router.post("/{repository_id}/sync")
async def sync_repository(
    repository_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Sync repository with remote"""
    return {
        "message": "Repository sync initiated",
        "sync_id": str(uuid.uuid4()),
        "status": "in_progress"
    }


@router.get("/{repository_id}/branches")
async def list_repository_branches(
    repository_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """List repository branches"""
    return [
        {"name": "main", "is_default": True, "last_commit": "abc123"},
        {"name": "develop", "is_default": False, "last_commit": "def456"},
        {"name": "feature/new-ui", "is_default": False, "last_commit": "ghi789"}
    ]


@router.get("/{repository_id}/analyses")
async def list_repository_analyses(
    repository_id: str,
    skip: int = Query(0, ge=0),
    limit: int = Query(10, ge=1, le=100),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """List analyses for repository"""
    # Mock data for demo
    return [
        {
            "id": "analysis-1",
            "status": "completed",
            "branch": "main",
            "commit_hash": "abc123",
            "created_at": "2024-01-01T12:00:00Z",
            "duration_seconds": 45,
            "findings_count": 12
        },
        {
            "id": "analysis-2",
            "status": "completed",
            "branch": "develop",
            "commit_hash": "def456",
            "created_at": "2024-01-01T11:00:00Z",
            "duration_seconds": 38,
            "findings_count": 8
        }
    ]