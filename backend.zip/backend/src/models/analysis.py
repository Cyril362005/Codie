"""
Data models for analysis requests and results
"""
from datetime import datetime
from typing import Dict, List, Optional
from pydantic import BaseModel, Field


class AnalysisRequest(BaseModel):
    """Request model for code analysis"""
    repository_url: str = Field(..., description="Repository URL or local path")
    branch: str = Field(default="main", description="Git branch to analyze")
    languages: Optional[List[str]] = Field(default=None, description="Target programming languages")
    analysis_type: str = Field(default="full", description="Type of analysis: static, dynamic, security, full")
    settings: Optional[Dict] = Field(default=None, description="Analysis configuration settings")


class Finding(BaseModel):
    """Individual code analysis finding"""
    finding_type: str = Field(..., description="Type of finding: security, performance, style, etc.")
    severity: str = Field(..., description="Severity level: critical, high, medium, low, info")
    confidence_score: float = Field(..., description="ML confidence score (0.0 to 1.0)")
    
    # Location information
    file_path: str = Field(..., description="Relative path to the file")
    line_start: int = Field(..., description="Starting line number")
    line_end: int = Field(..., description="Ending line number")
    column_start: Optional[int] = Field(default=None, description="Starting column")
    column_end: Optional[int] = Field(default=None, description="Ending column")
    
    # Finding details
    title: str = Field(..., description="Short title describing the issue")
    description: str = Field(..., description="Detailed description of the issue")
    recommendation: str = Field(..., description="Recommended fix or improvement")
    code_suggestion: Optional[str] = Field(default=None, description="Suggested code replacement")
    
    # External references
    cve_id: Optional[str] = Field(default=None, description="CVE identifier for security issues")
    rule_id: Optional[str] = Field(default=None, description="Internal rule identifier")


class AnalysisResult(BaseModel):
    """Complete analysis result"""
    analysis_id: str = Field(..., description="Unique analysis identifier")
    status: str = Field(..., description="Analysis status: pending, running, completed, failed")
    
    # Results
    findings: List[Finding] = Field(default=[], description="List of code analysis findings")
    dependency_graph: Optional[Dict] = Field(default=None, description="Repository dependency graph")
    hotspots: List[Dict] = Field(default=[], description="Code hotspots and complexity analysis")
    performance_metrics: Dict = Field(default={}, description="Performance analysis results")
    confidence_scores: Dict = Field(default={}, description="ML confidence scores for findings")
    
    # Metadata
    duration_seconds: int = Field(..., description="Analysis duration in seconds")
    summary: Dict = Field(default={}, description="Analysis summary statistics")
    error: Optional[str] = Field(default=None, description="Error message if analysis failed")
    created_at: datetime = Field(default_factory=datetime.utcnow, description="Analysis creation timestamp")


class AnalysisStatus(BaseModel):
    """Analysis status update"""
    analysis_id: str
    status: str
    progress: Optional[float] = Field(default=None, description="Progress percentage (0.0 to 1.0)")
    current_step: Optional[str] = Field(default=None, description="Current analysis step")
    message: Optional[str] = Field(default=None, description="Status message")