"""
Data models for chat and AI interactions
"""
from datetime import datetime
from typing import Dict, List, Optional
from pydantic import BaseModel, Field


class ChatMessage(BaseModel):
    """Individual chat message"""
    id: str = Field(..., description="Message identifier")
    content: str = Field(..., description="Message content")
    is_user: bool = Field(..., description="True if message is from user, False if from AI")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Message timestamp")
    context: Optional[Dict] = Field(default=None, description="Additional message context")


class ChatRequest(BaseModel):
    """Chat request from user"""
    message: str = Field(..., description="User message")
    analysis_id: Optional[str] = Field(default=None, description="Related analysis ID")
    context: Optional[Dict] = Field(default=None, description="Additional context for AI")
    conversation_history: Optional[List[ChatMessage]] = Field(default=None, description="Previous messages")


class CodeSuggestion(BaseModel):
    """Code suggestion from AI"""
    type: str = Field(..., description="Type of suggestion: replacement, addition, refactor")
    code: str = Field(..., description="Suggested code")
    description: str = Field(..., description="Description of the suggestion")
    file_path: Optional[str] = Field(default=None, description="Target file for suggestion")
    line_start: Optional[int] = Field(default=None, description="Starting line for replacement")
    line_end: Optional[int] = Field(default=None, description="Ending line for replacement")


class ChatResponse(BaseModel):
    """AI response to chat message"""
    message: str = Field(..., description="AI response message")
    confidence: float = Field(..., description="Response confidence (0.0 to 1.0)")
    suggestions: List[CodeSuggestion] = Field(default=[], description="Code suggestions")
    context: Optional[Dict] = Field(default=None, description="Updated context")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Response timestamp")


class ExplanationRequest(BaseModel):
    """Request for finding explanation"""
    finding_id: str = Field(..., description="Finding identifier")
    code_context: Optional[str] = Field(default=None, description="Surrounding code context")


class RefactoringRequest(BaseModel):
    """Request for refactoring suggestions"""
    code: str = Field(..., description="Code to refactor")
    language: str = Field(..., description="Programming language")
    issues: List[Dict] = Field(default=[], description="Known issues with the code")
    preferences: Optional[Dict] = Field(default=None, description="Refactoring preferences")