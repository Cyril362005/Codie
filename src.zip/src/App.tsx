import React, { useState } from 'react';
import Header from './components/layout/Header';
import MetricsCard from './components/dashboard/MetricsCard';
import RecentAnalysis from './components/dashboard/RecentAnalysis';
import CodeEditor from './components/analysis/CodeEditor';
import ChatInterface from './components/chat/ChatInterface';
import DependencyGraph from './components/visualization/DependencyGraph';
import SecurityDashboard from './components/security/SecurityDashboard';
import { TrendingUp, AlertTriangle, CheckCircle, Clock, Code, Upload, FileText, Play, Folder } from 'lucide-react';
import AuthModal from './components/auth/AuthModal';
import useAuth from './hooks/useAuth';
import ExportAnalysis from './components/dashboard/ExportAnalysis';
import AnalyzePanel from './components/analysis/AnalyzePanel';
import RepositoryManager from './components/RepositoryManager';
import RepoMiniCard from './components/dashboard/RepoMiniCard';

function App() {
  const [activeView, setActiveView] = useState('dashboard');
  const [code, setCode] = useState('');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authContextMsg, setAuthContextMsg] = useState<string | undefined>(undefined);
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [repoModalOpen, setRepoModalOpen] = useState(false);
  const { isAuthenticated } = useAuth();

  // Helper to require auth for protected actions
  const requireAuth = (action: () => void, contextMsg?: string) => {
    if (isAuthenticated) {
      action();
    } else {
      setAuthContextMsg(contextMsg || 'Sign in to continue.');
      setAuthModalOpen(true);
    }
  };

  const handleExportSuccess = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleAnalysisComplete = (result: any) => {
    setAnalysisResult(result);
    setToast('Analysis complete!');
    setTimeout(() => setToast(null), 3000);
  };

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            {/* Metrics Overview */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <MetricsCard title="Code Quality" value="A-" change="+12% this week" changeType="positive" icon={CheckCircle} subtitle="Overall health score" />
              <MetricsCard title="Issues Found" value="23" change="-18% from last scan" changeType="positive" icon={AlertTriangle} subtitle="Across 15 files" />
              <MetricsCard title="Avg Confidence" value="94%" change="+6% improvement" changeType="positive" icon={TrendingUp} subtitle="AI analysis accuracy" />
              <MetricsCard title="Scan Time" value="2m 34s" change="-45s faster" changeType="positive" icon={Clock} subtitle="Latest analysis" />
            </div>
            {/* Main Content Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <RecentAnalysis />
              </div>
              <div className="space-y-6">
                <RepoMiniCard
                  onNavigate={() => setActiveView('repositories')}
                  onOpenModal={() => setRepoModalOpen(true)}
                />
                {/* Quick Actions */}
                <div className="bg-white rounded-xl border border-gray-200 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
                  <div className="space-y-3">
                    <button
                      onClick={() => requireAuth(() => setActiveView('analyze'), 'Sign in to analyze new code.')}
                      className="w-full flex items-center space-x-3 p-3 text-left bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                    >
                      <Upload className="w-5 h-5 text-blue-600" />
                      <div>
                        <p className="font-medium text-blue-900">Analyze New Code</p>
                        <p className="text-sm text-blue-700">Upload files or connect repository</p>
                      </div>
                    </button>
                    <button
                      onClick={() => setActiveView('chat')}
                      className="w-full flex items-center space-x-3 p-3 text-left bg-emerald-50 hover:bg-emerald-100 rounded-lg transition-colors"
                    >
                      <Play className="w-5 h-5 text-emerald-600" />
                      <div>
                        <p className="font-medium text-emerald-900">Ask AI Assistant</p>
                        <p className="text-sm text-emerald-700">Get help with code issues</p>
                      </div>
                    </button>
                    <button
                      onClick={() => requireAuth(() => setExportModalOpen(true), 'Sign in to export reports.')}
                      className="w-full flex items-center space-x-3 p-3 text-left bg-purple-50 hover:bg-purple-100 rounded-lg transition-colors"
                    >
                      <FileText className="w-5 h-5 text-purple-600" />
                      <div>
                        <p className="font-medium text-purple-900">Export Report</p>
                        <p className="text-sm text-purple-700">Generate PDF or Markdown</p>
                      </div>
                    </button>
                  </div>
                </div>
                {/* Latest Insights */}
                <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-200 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Latest Insights</h3>
                  <div className="space-y-3">
                    <div className="flex items-start space-x-2">
                      <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-sm text-gray-700">Critical security vulnerability detected in authentication module</p>
                    </div>
                    <div className="flex items-start space-x-2">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-sm text-gray-700">3 functions have high cyclomatic complexity and should be refactored</p>
                    </div>
                    <div className="flex items-start space-x-2">
                      <div className="w-2 h-2 bg-emerald-500 rounded-full mt-2 flex-shrink-0"></div>
                      <p className="text-sm text-gray-700">Test coverage improved by 15% since last analysis</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      case 'repositories':
        return <RepositoryManager />;
      case 'analyze':
        return (
          <div className="space-y-6">
            {/* Analysis Header */}
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">Code Analysis</h2>
                  <p className="text-gray-600">Upload code or connect a repository for comprehensive analysis</p>
                </div>
              </div>
            </div>
            {/* AnalyzePanel */}
            <AnalyzePanel onAnalysisComplete={handleAnalysisComplete} />
            {/* Optionally show analysis results here */}
            {analysisResult && (
              <div className="bg-white rounded-xl border border-emerald-300 p-6 mt-4">
                <h3 className="text-lg font-semibold text-emerald-700 mb-2">Analysis Results</h3>
                <pre className="text-xs text-gray-800 bg-gray-50 rounded p-2 overflow-x-auto max-h-64">{JSON.stringify(analysisResult, null, 2)}</pre>
              </div>
            )}
          </div>
        );
      case 'chat':
        return (
          <div className="bg-white rounded-xl border border-gray-200 overflow-hidden" style={{ height: '700px' }}>
            <ChatInterface />
          </div>
        );
      case 'security':
        return <SecurityDashboard />;
      default:
        return (
          <div className="space-y-6">
            <DependencyGraph />
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header activeView={activeView} onViewChange={setActiveView} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Sidebar nav for main views */}
        <nav className="mb-8 flex gap-4">
          <button
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${activeView === 'dashboard' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-blue-50'}`}
            onClick={() => setActiveView('dashboard')}
          >
            <span>Dashboard</span>
          </button>
          <button
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${activeView === 'repositories' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-blue-50'}`}
            onClick={() => setActiveView('repositories')}
          >
            <Folder className="w-5 h-5" />
            <span>Repositories</span>
          </button>
        </nav>
        {renderContent()}
        {/* Global modal for Add New Repository from dashboard card */}
        {repoModalOpen && activeView === 'dashboard' && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
            <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md relative">
              <button
                className="absolute top-3 right-3 text-gray-400 hover:text-gray-700"
                onClick={() => setRepoModalOpen(false)}
                aria-label="Close modal"
              >
                ×
              </button>
              <h2 className="text-xl font-semibold mb-4 text-gray-900">New Repository</h2>
              {/* Reuse RepositoryManager's form logic or duplicate minimal form here if needed */}
              {/* For now, instruct user to use full Repositories view for advanced options */}
              <p className="text-gray-600 mb-4">For advanced options, use the full Repositories view.</p>
              {/* Optionally, render a minimal form here */}
            </div>
          </div>
        )}
      </main>
      <AuthModal open={authModalOpen} onClose={() => setAuthModalOpen(false)} contextMessage={authContextMsg} />
      {exportModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl p-0 max-w-md w-full relative">
            <button
              className="absolute top-3 right-3 text-gray-400 hover:text-gray-700"
              onClick={() => setExportModalOpen(false)}
              aria-label="Close export modal"
            >
              ×
            </button>
            <ExportAnalysis />
          </div>
        </div>
      )}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white px-6 py-3 rounded-lg shadow-lg animate-fade-in">
          {toast}
        </div>
      )}
    </div>
  );
}

export default App;