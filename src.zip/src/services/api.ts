/**
 * API service for communicating with the backend
 */

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1';

interface ApiResponse<T> {
  data?: T;
  error?: string;
  status: number;
}

class ApiService {
  private baseURL: string;
  private token: string | null = null;

  constructor(baseURL: string = API_BASE_URL) {
    this.baseURL = baseURL;
    this.token = localStorage.getItem('auth_token');
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    const url = `${this.baseURL}${endpoint}`;
    
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    if (this.token) {
      (headers as Record<string, string>)["Authorization"] = `Bearer ${this.token}`;
    }

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      const data = await response.json();

      if (!response.ok) {
        return {
          error: data.detail || 'An error occurred',
          status: response.status,
        };
      }

      return {
        data,
        status: response.status,
      };
    } catch (error) {
      return {
        error: error instanceof Error ? error.message : 'Network error',
        status: 0,
      };
    }
  }

  // Authentication
  async login(email: string, password: string) {
    const response = await this.request<{ access_token: string; token_type: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });

    if (response.data) {
      this.token = response.data.access_token;
      localStorage.setItem('auth_token', this.token);
    }

    return response;
  }

  async register(email: string, password: string, fullName?: string) {
    const response = await this.request<{ access_token: string; token_type: string }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, password, full_name: fullName }),
    });

    if (response.data) {
      this.token = response.data.access_token;
      localStorage.setItem('auth_token', this.token);
    }

    return response;
  }

  async logout() {
    await this.request('/auth/logout', { method: 'POST' });
    this.token = null;
    localStorage.removeItem('auth_token');
  }

  async getCurrentUser() {
    return this.request<{
      id: string;
      email: string;
      full_name: string;
      is_active: boolean;
    }>('/auth/me');
  }

  // Analysis
  async createAnalysis(data: {
    repository_url: string;
    branch?: string;
    languages?: string[];
    analysis_type?: string;
  }) {
    return this.request<{
      analysis_id: string;
      status: string;
      findings: any[];
      duration_seconds: number;
      summary: any;
    }>('/analysis', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async getAnalysis(analysisId: string) {
    return this.request<{
      analysis_id: string;
      status: string;
      findings: any[];
      dependency_graph: any;
      hotspots: any[];
      performance_metrics: any;
      confidence_scores: any;
      duration_seconds: number;
      summary: any;
    }>(`/analysis/${analysisId}`);
  }

  async getAnalysisStatus(analysisId: string) {
    return this.request<{
      analysis_id: string;
      status: string;
      progress: number;
      current_step: string;
      message: string;
    }>(`/analysis/${analysisId}/status`);
  }

  async listAnalyses(params?: { skip?: number; limit?: number; status?: string }) {
    const searchParams = new URLSearchParams();
    if (params?.skip) searchParams.append('skip', params.skip.toString());
    if (params?.limit) searchParams.append('limit', params.limit.toString());
    if (params?.status) searchParams.append('status', params.status);

    return this.request<any[]>(`/analysis?${searchParams.toString()}`);
  }

  async exportAnalysis(analysisId: string, format: string = 'pdf') {
    return this.request<{ download_url: string; expires_at: string }>(`/analysis/${analysisId}/export?format=${format}`, {
      method: 'POST',
    });
  }

  async getCVEDetails(cveId: string) {
    return this.request<{
      cve_id: string;
      title: string;
      description: string;
      severity: string;
      cvss_score: number;
      published_date: string;
      affected_versions: string[];
      patched_versions: string[];
      references: string[];
    }>(`/security/cve/${cveId}`);
  }

  async startSecurityScan(repositoryId: string, scanType: string = 'full') {
    return this.request<{
      scan_id: string;
      status: string;
      repository_id: string;
      scan_type: string;
      estimated_duration: string;
    }>('/security/scan', {
      method: 'POST',
      body: JSON.stringify({ repository_id: repositoryId, scan_type: scanType }),
    });
  }

  // Chat
  async sendChatMessage(data: {
    message: string;
    analysis_id?: string;
    context?: any;
    conversation_history?: any[];
  }) {
    return this.request<{
      message: string;
      confidence: number;
      suggestions: any[];
      context: any;
      timestamp: string;
    }>('/chat', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async explainFinding(findingId: string, codeContext?: string) {
    return this.request<string>('/chat/explain', {
      method: 'POST',
      body: JSON.stringify({ finding_id: findingId, code_context: codeContext }),
    });
  }

  async suggestRefactoring(data: {
    code: string;
    language: string;
    issues: any[];
    preferences?: any;
  }) {
    return this.request<{
      recommendations: string;
      confidence: number;
    }>('/chat/refactor', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  // Repositories
  async createRepository(data: {
    name: string;
    url?: string;
    description?: string;
    languages?: string[];
    is_private?: boolean;
  }) {
    return this.request<{
      id: string;
      name: string;
      url: string;
      description: string;
      languages: string[];
      created_at: string;
    }>('/repositories', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async listRepositories(params?: { skip?: number; limit?: number; search?: string }) {
    const searchParams = new URLSearchParams();
    if (params?.skip) searchParams.append('skip', params.skip.toString());
    if (params?.limit) searchParams.append('limit', params.limit.toString());
    if (params?.search) searchParams.append('search', params.search);

    return this.request<any[]>(`/repositories?${searchParams.toString()}`);
  }

  async getRepository(repositoryId: string) {
    return this.request<{
      id: string;
      name: string;
      url: string;
      description: string;
      languages: string[];
      total_analyses: number;
      last_analysis_at: string;
    }>(`/repositories/${repositoryId}`);
  }

  async updateRepository(repositoryId: string, data: {
    name?: string;
    description?: string;
    languages?: string[];
    style_preferences?: any;
    analysis_settings?: any;
  }) {
    return this.request(`/repositories/${repositoryId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async deleteRepository(repositoryId: string) {
    return this.request(`/repositories/${repositoryId}`, {
      method: 'DELETE',
    });
  }

  async syncRepository(repositoryId: string) {
    return this.request(`/repositories/${repositoryId}/sync`, {
      method: 'POST',
    });
  }

  // Security
  async getSecuritySummary(repositoryId?: string) {
    const params = repositoryId ? `?repository_id=${repositoryId}` : '';
    return this.request<{
      total_findings: number;
      critical_count: number;
      high_count: number;
      medium_count: number;
      low_count: number;
      resolved_count: number;
      avg_confidence: number;
      last_scan_at: string;
    }>(`/security/summary${params}`);
  }

  async listSecurityFindings(params?: {
    repository_id?: string;
    severity?: string;
    status?: string;
    skip?: number;
    limit?: number;
  }) {
    const searchParams = new URLSearchParams();
    if (params?.repository_id) searchParams.append('repository_id', params.repository_id);
    if (params?.severity) searchParams.append('severity', params.severity);
    if (params?.status) searchParams.append('status', params.status);
    if (params?.skip) searchParams.append('skip', params.skip.toString());
    if (params?.limit) searchParams.append('limit', params.limit.toString());

    return this.request<any[]>(`/security/findings?${searchParams.toString()}`);
  }

  async getSecurityFinding(findingId: string) {
    return this.request<{
      id: string;
      severity: string;
      title: string;
      description: string;
      file_path: string;
      line_number: number;
      cve_id: string;
      confidence: number;
      remediation: string;
      status: string;
    }>(`/security/findings/${findingId}`);
  }
}

export const apiService = new ApiService();
export default apiService;