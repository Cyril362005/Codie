export interface Repository {
  id: string;
  name: string;
  url?: string;
  description?: string;
  languages?: string[];
  default_branch?: string;
  is_private?: boolean;
  created_at?: string;
  updated_at?: string;
  style_preferences?: any;
  analysis_settings?: any;
  total_analyses?: number;
  last_analysis_at?: string;
} 