import { useState, useCallback } from 'react';
import apiService from '../services/api';
import { Repository } from '../types/Repository';

export function useRepositories() {
  const [repositories, setRepositories] = useState<Repository[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const fetchRepositories = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await apiService.listRepositories();
      if (res.data) {
        setRepositories(res.data);
      } else {
        setError(res.error || 'Failed to fetch repositories');
      }
    } catch (e) {
      setError('Failed to fetch repositories');
    } finally {
      setLoading(false);
    }
  }, []);

  const createRepository = useCallback(async (data: Partial<Repository>) => {
    setLoading(true);
    setError(null);
    setSuccess(null);
    try {
      const res = await apiService.createRepository(data);
      if (res.data) {
        setRepositories((prev) => [res.data, ...prev]);
        setSuccess('Repository created successfully');
      } else {
        setError(res.error || 'Failed to create repository');
      }
    } catch (e) {
      setError('Failed to create repository');
    } finally {
      setLoading(false);
    }
  }, []);

  const updateRepository = useCallback(async (id: string, data: Partial<Repository>) => {
    setLoading(true);
    setError(null);
    setSuccess(null);
    try {
      const res = await apiService.updateRepository(id, data);
      if (res.data) {
        setRepositories((prev) => prev.map(r => r.id === id ? { ...r, ...res.data } : r));
        setSuccess('Repository updated successfully');
      } else {
        setError(res.error || 'Failed to update repository');
      }
    } catch (e) {
      setError('Failed to update repository');
    } finally {
      setLoading(false);
    }
  }, []);

  const deleteRepository = useCallback(async (id: string) => {
    setLoading(true);
    setError(null);
    setSuccess(null);
    try {
      const res = await apiService.deleteRepository(id);
      if (res.data || res.status === 200) {
        setRepositories((prev) => prev.filter(r => r.id !== id));
        setSuccess('Repository deleted successfully');
      } else {
        setError(res.error || 'Failed to delete repository');
      }
    } catch (e) {
      setError('Failed to delete repository');
    } finally {
      setLoading(false);
    }
  }, []);

  const syncRepository = useCallback(async (id: string) => {
    setLoading(true);
    setError(null);
    setSuccess(null);
    try {
      const res = await apiService.syncRepository(id);
      if (res.data) {
        setSuccess('Repository sync started');
      } else {
        setError(res.error || 'Failed to sync repository');
      }
    } catch (e) {
      setError('Failed to sync repository');
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    repositories,
    loading,
    error,
    success,
    fetchRepositories,
    createRepository,
    updateRepository,
    deleteRepository,
    syncRepository,
    setError,
    setSuccess,
    setRepositories,
  };
} 