import { useState, useEffect, useCallback } from 'react';
import apiService from '../services/api';

interface User {
  id: string;
  email: string;
  full_name?: string;
  is_active: boolean;
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // On mount, check for token and fetch user
  useEffect(() => {
    const token = localStorage.getItem('auth_token');
    if (token) {
      setLoading(true);
      apiService.getCurrentUser().then((res) => {
        if (res.data) setUser(res.data);
        setLoading(false);
      });
    }
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    setLoading(true);
    setError(null);
    const res = await apiService.login(email, password);
    if (res.data) {
      setUser(await apiService.getCurrentUser().then(r => r.data || null));
      setLoading(false);
      return true;
    } else {
      setError(res.error || 'Incorrect email or password, try again or reset.');
      setLoading(false);
      return false;
    }
  }, []);

  const register = useCallback(async (email: string, password: string, fullName?: string) => {
    setLoading(true);
    setError(null);
    const res = await apiService.register(email, password, fullName);
    if (res.data) {
      setUser(await apiService.getCurrentUser().then(r => r.data || null));
      setLoading(false);
      return true;
    } else {
      setError(res.error || 'Registration failed. Try again.');
      setLoading(false);
      return false;
    }
  }, []);

  const logout = useCallback(async () => {
    await apiService.logout();
    setUser(null);
  }, []);

  return {
    user,
    loading,
    error,
    login,
    register,
    logout,
    isAuthenticated: !!user,
    setError,
  };
}

export default useAuth; 