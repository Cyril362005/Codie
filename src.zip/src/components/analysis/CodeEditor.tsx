import React, { useRef, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { AlertCircle, CheckCircle, Info, Shield } from 'lucide-react';
import apiService from '../../services/api';

interface Finding {
  id: string;
  type: 'error' | 'warning' | 'info' | 'security';
  line: number;
  column: number;
  message: string;
  confidence: number;
  suggestion?: string;
}

interface CodeEditorProps {
  code: string;
  language: string;
  findings: Finding[];
  onCodeChange: (code: string) => void;
}

const sampleCode = `import React, { useState, useEffect } from 'react';
import { fetchUserData } from '../api/users';

const UserProfile = ({ userId }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Potential security issue: unvalidated user input
    const loadUser = async () => {
      try {
        const userData = await fetchUserData(userId);
        setUser(userData);
      } catch (error) {
        console.log(error); // Should use proper logging
      } finally {
        setLoading(false);
      }
    };
    
    loadUser();
  }, [userId]);
  
  // Performance issue: inefficient rendering
  const formatUserData = () => {
    if (!user) return null;
    
    return Object.keys(user).map(key => (
      <div key={key}>
        <strong>{key}:</strong> {user[key]}
      </div>
    ));
  };
  
  if (loading) {
    return <div>Loading...</div>;
  }
  
  return (
    <div className="user-profile">
      <h2>{user?.name || 'Unknown User'}</h2>
      {formatUserData()}
    </div>
  );
};

export default UserProfile;`;

const mockFindings: Finding[] = [
  {
    id: '1',
    type: 'security',
    line: 9,
    column: 40,
    message: 'Potential SQL injection vulnerability: User input not validated',
    confidence: 92,
    suggestion: 'Validate and sanitize userId before using in database queries'
  },
  {
    id: '2',
    type: 'warning',
    line: 14,
    column: 17,
    message: 'Console.log should not be used in production',
    confidence: 85,
    suggestion: 'Use proper logging framework instead of console.log'
  },
  {
    id: '3',
    type: 'warning',
    line: 22,
    column: 5,
    message: 'Function recreated on every render - consider useCallback',
    confidence: 78,
    suggestion: 'Wrap formatUserData with useCallback to prevent unnecessary re-renders'
  },
  {
    id: '4',
    type: 'info',
    line: 34,
    column: 10,
    message: 'Optional chaining can be simplified',
    confidence: 65,
    suggestion: 'Consider using default parameter or nullish coalescing'
  }
];

export default function CodeEditor({ code = sampleCode, language = 'typescript', findings = mockFindings, onCodeChange }: CodeEditorProps) {
  const editorRef = useRef<any>(null);

  const handleEditorDidMount = (editor: any, monaco: any) => {
    editorRef.current = editor;
    
    // Add decorations for findings
    const decorations = findings.map(finding => ({
      range: new monaco.Range(finding.line, finding.column, finding.line, finding.column + 10),
      options: {
        isWholeLine: false,
        className: `finding-${finding.type}`,
        glyphMarginClassName: `glyph-${finding.type}`,
        hoverMessage: { value: finding.message },
        minimap: {
          color: finding.type === 'error' ? '#ef4444' : finding.type === 'warning' ? '#f59e0b' : '#3b82f6',
          position: monaco.editor.MinimapPosition.Inline
        }
      }
    }));
    
    editor.deltaDecorations([], decorations);
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'error':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'warning':
        return <AlertCircle className="w-4 h-4 text-yellow-500" />;
      case 'security':
        return <Shield className="w-4 h-4 text-red-600" />;
      case 'info':
        return <Info className="w-4 h-4 text-blue-500" />;
      default:
        return <CheckCircle className="w-4 h-4 text-emerald-500" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'error':
        return 'border-l-red-500 bg-red-50';
      case 'warning':
        return 'border-l-yellow-500 bg-yellow-50';
      case 'security':
        return 'border-l-red-600 bg-red-50';
      case 'info':
        return 'border-l-blue-500 bg-blue-50';
      default:
        return 'border-l-emerald-500 bg-emerald-50';
    }
  };

  return (
    <div className="flex h-full">
      {/* Code Editor */}
      <div className="flex-1 border-r border-gray-200">
        <div className="h-full">
          <Editor
            height="100%"
            language={language}
            value={code}
            onChange={(value) => onCodeChange(value || '')}
            onMount={handleEditorDidMount}
            theme="vs"
            options={{
              minimap: { enabled: true },
              fontSize: 14,
              lineNumbers: 'on',
              glyphMargin: true,
              folding: true,
              lineDecorationsWidth: 10,
              scrollBeyondLastLine: false,
              automaticLayout: true,
              wordWrap: 'on',
              contextmenu: true,
              selectOnLineNumbers: true
            }}
          />
        </div>
      </div>

      {/* Findings Panel */}
      <div className="w-80 bg-gray-50 p-4 overflow-y-auto">
        <div className="mb-4">
          <h3 className="text-sm font-semibold text-gray-900 mb-2">Analysis Results</h3>
          <div className="text-xs text-gray-600">
            {findings.length} issues found • Average confidence: {Math.round(findings.reduce((acc, f) => acc + f.confidence, 0) / findings.length)}%
          </div>
        </div>

        <div className="space-y-3">
          {findings.map((finding) => (
            <div
              key={finding.id}
              className={`border-l-4 p-3 rounded-r-lg ${getTypeColor(finding.type)} cursor-pointer hover:shadow-sm transition-shadow`}
              onClick={() => {
                if (editorRef.current) {
                  editorRef.current.setPosition({ lineNumber: finding.line, column: finding.column });
                  editorRef.current.focus();
                }
              }}
            >
              <div className="flex items-start space-x-2">
                {getIcon(finding.type)}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-gray-900 uppercase tracking-wide">
                      {finding.type}
                    </span>
                    <span className="text-xs text-gray-500">
                      {finding.confidence}% confident
                    </span>
                  </div>
                  <p className="text-sm text-gray-700 mb-2">{finding.message}</p>
                  <div className="text-xs text-gray-600 mb-2">
                    Line {finding.line}, Column {finding.column}
                  </div>
                  {finding.suggestion && (
                    <div className="mt-2 p-2 bg-white rounded border border-gray-200">
                      <p className="text-xs text-gray-700">
                        <span className="font-medium">Suggestion:</span> {finding.suggestion}
                      </p>
                    </div>
                  )}
                  <div className="mt-2 flex space-x-2">
                    <button 
                      className="text-xs bg-blue-100 hover:bg-blue-200 text-blue-700 px-2 py-1 rounded transition-colors"
                      onClick={async (e) => {
                        e.stopPropagation();
                        try {
                          const explanation = await apiService.explainFinding(finding.id, code);
                          if (explanation.data) {
                            alert(explanation.data); // In real app, show in modal or sidebar
                          }
                        } catch (error) {
                          console.error('Failed to get explanation:', error);
                        }
                      }}
                    >
                      Explain
                    </button>
                    <button 
                      className="text-xs bg-green-100 hover:bg-green-200 text-green-700 px-2 py-1 rounded transition-colors"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (finding.suggestion && editorRef.current) {
                          // Apply suggestion to editor
                          const model = editorRef.current.getModel();
                          if (model) {
                            const range = {
                              startLineNumber: finding.line,
                              startColumn: 1,
                              endLineNumber: finding.line,
                              endColumn: model.getLineMaxColumn(finding.line)
                            };
                            editorRef.current.executeEdits('apply-suggestion', [{
                              range,
                              text: finding.suggestion
                            }]);
                          }
                        }
                      }}
                    >
                      Apply Fix
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}