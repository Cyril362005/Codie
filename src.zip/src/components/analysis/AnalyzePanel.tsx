import React, { useRef, useState } from 'react';
import apiService from '../../services/api';

const MAX_FILE_SIZE_MB = 10;
const SUPPORTED_FORMATS = ['.zip', '.py', '.js', '.ts', '.java'];

interface UploadedFile {
  file: File;
  error?: string;
}

export default function AnalyzePanel({ onAnalysisComplete }: { onAnalysisComplete: (result: any) => void }) {
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [language, setLanguage] = useState('auto');
  const [projectName, setProjectName] = useState('');
  const [description, setDescription] = useState('');
  const [tags, setTags] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFiles = (fileList: FileList) => {
    const newFiles: UploadedFile[] = [];
    Array.from(fileList).forEach((file) => {
      const ext = file.name.slice(file.name.lastIndexOf('.')).toLowerCase();
      if (!SUPPORTED_FORMATS.includes(ext)) {
        newFiles.push({ file, error: 'Unsupported file type' });
      } else if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
        newFiles.push({ file, error: `File too large (max ${MAX_FILE_SIZE_MB}MB)` });
      } else {
        newFiles.push({ file });
      }
    });
    setFiles(newFiles);
    setError(null);
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files) handleFiles(e.dataTransfer.files);
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) handleFiles(e.target.files);
  };

  const canAnalyze = files.length > 0 && files.every(f => !f.error);

  const handleAnalyze = async () => {
    setAnalyzing(true);
    setProgress(0);
    setError(null);
    setToast(null);
    try {
      // For demo: just send the first file and metadata
      const formData = new FormData();
      files.forEach(f => formData.append('files', f.file));
      formData.append('project_name', projectName);
      formData.append('language', language);
      formData.append('description', description);
      formData.append('tags', tags);
      // Simulate progress
      setProgress(20);
      // TODO: Replace with real API call
      const res = await apiService.createAnalysis({
        repository_url: 'uploaded', // Placeholder
        languages: language === 'auto' ? undefined : [language],
        analysis_type: 'full',
      });
      setProgress(100);
      if (res.data) {
        onAnalysisComplete(res.data);
      } else {
        setError(res.error || 'Analysis failed.');
        setToast(res.error || 'Analysis failed.');
      }
    } catch (e) {
      setError('Analysis failed.');
      setToast('Analysis failed.');
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div
        className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center bg-gray-50 cursor-pointer hover:border-blue-400 transition-colors"
        onDrop={onDrop}
        onDragOver={e => e.preventDefault()}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          className="hidden"
          onChange={onFileChange}
          accept={SUPPORTED_FORMATS.join(',')}
        />
        <p className="text-lg font-semibold text-gray-700 mb-2">Upload a file or drag and drop here</p>
        <p className="text-sm text-gray-500">Supported: {SUPPORTED_FORMATS.join(', ')} • Max {MAX_FILE_SIZE_MB}MB each</p>
      </div>
      {files.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <h4 className="font-medium mb-2">Files to Analyze</h4>
          <ul className="space-y-1">
            {files.map((f, i) => (
              <li key={i} className="flex items-center justify-between text-sm">
                <span>{f.file.name} ({(f.file.size / 1024 / 1024).toFixed(2)} MB)</span>
                {f.error ? <span className="text-red-600">{f.error}</span> : <span className="text-emerald-600">Ready</span>}
              </li>
            ))}
          </ul>
        </div>
      )}
      {/* Custom summary fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Project Name</label>
          <input
            type="text"
            className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 border-gray-300"
            value={projectName}
            onChange={e => setProjectName(e.target.value)}
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Language</label>
          <select
            className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 border-gray-300"
            value={language}
            onChange={e => setLanguage(e.target.value)}
          >
            <option value="auto">Auto-detect</option>
            <option value="python">Python</option>
            <option value="javascript">JavaScript</option>
            <option value="typescript">TypeScript</option>
            <option value="java">Java</option>
          </select>
        </div>
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700">Description</label>
          <textarea
            className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 border-gray-300"
            value={description}
            onChange={e => setDescription(e.target.value)}
            rows={2}
          />
        </div>
        <div className="md:col-span-2">
          <label className="block text-sm font-medium text-gray-700">Tags</label>
          <input
            type="text"
            className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 border-gray-300"
            value={tags}
            onChange={e => setTags(e.target.value)}
            placeholder="comma,separated,keywords"
          />
        </div>
      </div>
      {error && <div className="text-red-600 text-sm bg-red-50 border border-red-200 rounded p-2">{error}</div>}
      {analyzing && (
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div className="bg-blue-600 h-2 rounded-full transition-all" style={{ width: `${progress}%` }} />
        </div>
      )}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-red-600 text-white px-6 py-3 rounded-lg shadow-lg animate-fade-in">
          {toast}
        </div>
      )}
      <button
        className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
        disabled={!canAnalyze || analyzing}
        onClick={handleAnalyze}
      >
        {analyzing ? 'Analyzing...' : 'Analyze'}
      </button>
    </div>
  );
} 