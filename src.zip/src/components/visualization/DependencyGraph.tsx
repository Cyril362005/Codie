import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { TrendingUp, TrendingDown, AlertTriangle, CheckCircle } from 'lucide-react';

const complexityData = [
  { name: 'UserService.js', complexity: 15, issues: 8, hotspot: true },
  { name: 'AuthHandler.js', complexity: 12, issues: 3, hotspot: false },
  { name: 'DataProcessor.js', complexity: 20, issues: 12, hotspot: true },
  { name: 'APIClient.js', complexity: 8, issues: 2, hotspot: false },
  { name: 'ValidationUtils.js', complexity: 6, issues: 1, hotspot: false },
  { name: 'Router.js', complexity: 18, issues: 9, hotspot: true },
];

const issueTypeData = [
  { name: 'Security', value: 12, color: '#ef4444' },
  { name: 'Performance', value: 8, color: '#f59e0b' },
  { name: 'Maintainability', value: 15, color: '#3b82f6' },
  { name: 'Style', value: 6, color: '#8b5cf6' },
];

const trendData = [
  { date: 'Week 1', issues: 45, confidence: 85 },
  { date: 'Week 2', issues: 38, confidence: 88 },
  { date: 'Week 3', issues: 42, confidence: 87 },
  { date: 'Week 4', issues: 29, confidence: 92 },
  { date: 'Week 5', issues: 23, confidence: 94 },
];

export default function DependencyGraph() {
  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Issues</p>
              <p className="text-2xl font-bold text-gray-900">41</p>
            </div>
            <div className="flex items-center text-emerald-600">
              <TrendingDown className="w-4 h-4 mr-1" />
              <span className="text-sm font-medium">-18%</span>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg Confidence</p>
              <p className="text-2xl font-bold text-gray-900">94%</p>
            </div>
            <div className="flex items-center text-emerald-600">
              <TrendingUp className="w-4 h-4 mr-1" />
              <span className="text-sm font-medium">+6%</span>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Hotspots</p>
              <p className="text-2xl font-bold text-gray-900">3</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-yellow-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Code Quality</p>
              <p className="text-2xl font-bold text-gray-900">A-</p>
            </div>
            <CheckCircle className="w-8 h-8 text-emerald-500" />
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Complexity Analysis */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Complexity Analysis</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={complexityData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} fontSize={12} />
              <YAxis />
              <Tooltip />
              <Bar dataKey="complexity" fill="#3b82f6" name="Complexity Score" />
              <Bar dataKey="issues" fill="#ef4444" name="Issues Found" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Issue Distribution */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Issue Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={issueTypeData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {issueTypeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Trend Analysis */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quality Trends</h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={trendData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="date" />
            <YAxis yAxisId="left" />
            <YAxis yAxisId="right" orientation="right" />
            <Tooltip />
            <Line yAxisId="left" type="monotone" dataKey="issues" stroke="#ef4444" strokeWidth={2} name="Issues" />
            <Line yAxisId="right" type="monotone" dataKey="confidence" stroke="#3b82f6" strokeWidth={2} name="Confidence %" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Hotspots Table */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Code Hotspots</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-900">File</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Complexity</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Issues</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Priority</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Action</th>
              </tr>
            </thead>
            <tbody>
              {complexityData
                .filter(item => item.hotspot)
                .map((file, index) => (
                  <tr key={index} className="border-b border-gray-100 hover:bg-gray-50">
                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-2">
                        <AlertTriangle className="w-4 h-4 text-yellow-500" />
                        <span className="font-medium text-gray-900">{file.name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        file.complexity > 15 ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {file.complexity}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-900">{file.issues}</td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-1 bg-red-100 text-red-800 rounded-full text-xs font-medium">
                        High
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <button className="text-blue-600 hover:text-blue-700 text-sm font-medium">
                        View Details
                      </button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}