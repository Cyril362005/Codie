import React from 'react';
import { Folder, Plus, RefreshCw } from 'lucide-react';
import { useRepositories } from '../../hooks/useRepositories';

interface RepoMiniCardProps {
  onNavigate: () => void;
  onOpenModal: () => void;
}

export default function RepoMiniCard({ onNavigate, onOpenModal }: RepoMiniCardProps) {
  const {
    repositories,
    loading,
    syncRepository,
    setError,
    setSuccess,
    fetchRepositories,
  } = useRepositories();

  const topRepos = [...repositories]
    .sort((a, b) => (b.updated_at || '').localeCompare(a.updated_at || ''))
    .slice(0, 3);

  const handleSyncAll = async () => {
    try {
      await Promise.all(topRepos.map(r => syncRepository(r.id)));
      setSuccess && setSuccess('Sync started for all listed repositories.');
      fetchRepositories();
    } catch {
      setError && setError('Failed to sync all repositories.');
    }
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6 shadow hover:shadow-lg transition-all cursor-pointer group">
      <div className="flex items-center justify-between mb-2" onClick={onNavigate} role="button" tabIndex={0} aria-label="Go to repositories view">
        <div className="flex items-center gap-2">
          <Folder className="w-5 h-5 text-blue-600" />
          <h3 className="text-lg font-semibold text-gray-900 group-hover:underline">Repositories</h3>
        </div>
        <span className="text-xs text-gray-500">Manage source integrations</span>
      </div>
      <ul className="mt-4 space-y-2">
        {topRepos.length === 0 && !loading && (
          <li className="text-gray-400 text-sm">No repositories found.</li>
        )}
        {topRepos.map((repo) => (
          <li key={repo.id} className="flex items-center justify-between text-sm">
            <span className="font-medium text-gray-800 truncate max-w-[120px]">{repo.name}</span>
            <span className="text-xs text-gray-500">{repo.updated_at ? new Date(repo.updated_at).toLocaleDateString() : '-'}</span>
          </li>
        ))}
      </ul>
      <div className="flex gap-2 mt-6">
        <button
          className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-lg font-medium transition-colors"
          onClick={e => { e.stopPropagation(); handleSyncAll(); }}
          disabled={loading || topRepos.length === 0}
        >
          <RefreshCw className="w-4 h-4" /> Sync All
        </button>
        <button
          className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg font-medium transition-colors"
          onClick={e => { e.stopPropagation(); onOpenModal(); }}
        >
          <Plus className="w-4 h-4" /> Add New
        </button>
      </div>
    </div>
  );
} 