import React, { useEffect, useState } from 'react';
import apiService from '../../services/api';

interface AnalysisSummary {
  analysis_id: string;
  status: string;
  summary: any;
  created_at?: string;
}

const EXPORT_FORMATS = [
  { label: 'PDF', value: 'pdf' },
  { label: 'HTML', value: 'html' },
  { label: 'JSON', value: 'json' },
];

export default function ExportAnalysis() {
  const [analyses, setAnalyses] = useState<AnalysisSummary[]>([]);
  const [selectedId, setSelectedId] = useState<string | undefined>(undefined);
  const [format, setFormat] = useState('pdf');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    apiService.listAnalyses().then((res) => {
      if (res.data) {
        setAnalyses(res.data);
        if (res.data.length > 0) setSelectedId(res.data[0].analysis_id);
      } else {
        setToast(res.error || 'Failed to fetch analyses.');
      }
    }).catch(() => setToast('Failed to fetch analyses.'));
  }, []);

  const handleExport = async () => {
    if (!selectedId) return;
    setLoading(true);
    setError(null);
    setSuccess(null);
    try {
      const res = await apiService.exportAnalysis(selectedId, format);
      const downloadUrl = (res.data as any)?.download_url;
      if (downloadUrl) {
        window.open(downloadUrl, '_blank');
        setSuccess('Export started. Your download should begin shortly.');
      } else {
        setError(res.error || 'Export failed.');
        setToast(res.error || 'Export failed.');
      }
    } catch (e) {
      setError('Export failed.');
      setToast('Export failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Export Analysis</h3>
      {analyses.length === 0 ? (
        <p className="text-gray-600">No analyses available to export.</p>
      ) : (
        <>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Select Analysis</label>
            <select
              className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 border-gray-300"
              value={selectedId}
              onChange={e => setSelectedId(e.target.value)}
            >
              {analyses.map(a => (
                <option key={a.analysis_id} value={a.analysis_id}>
                  {a.summary?.project_name || a.analysis_id} ({a.created_at || 'unknown'})
                </option>
              ))}
            </select>
          </div>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-1">Format</label>
            <select
              className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 border-gray-300"
              value={format}
              onChange={e => setFormat(e.target.value)}
            >
              {EXPORT_FORMATS.map(f => (
                <option key={f.value} value={f.value}>{f.label}</option>
              ))}
            </select>
          </div>
          {error && <div className="text-red-600 text-sm bg-red-50 border border-red-200 rounded p-2 mb-2">{error}</div>}
          {success && <div className="text-emerald-600 text-sm bg-emerald-50 border border-emerald-200 rounded p-2 mb-2">{success}</div>}
          {toast && (
            <div className="fixed bottom-6 right-6 z-50 bg-red-600 text-white px-6 py-3 rounded-lg shadow-lg animate-fade-in">
              {toast}
            </div>
          )}
          <button
            className="px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={!selectedId || loading}
            onClick={handleExport}
          >
            {loading ? 'Exporting...' : 'Export'}
          </button>
        </>
      )}
    </div>
  );
} 