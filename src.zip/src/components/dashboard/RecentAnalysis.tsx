import React, { useEffect, useState } from 'react';
import apiService from '../../services/api';

interface AnalysisSummary {
  analysis_id: string;
  status: string;
  summary: any;
  duration_seconds?: number;
  created_at?: string;
}

const EXPORT_FORMATS = [
  { label: 'PDF', value: 'pdf' },
  { label: 'Markdown', value: 'markdown' },
  { label: 'JSON', value: 'json' },
];

export default function RecentAnalysis() {
  const [analyses, setAnalyses] = useState<AnalysisSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [modalLoading, setModalLoading] = useState(false);
  const [modalData, setModalData] = useState<any>(null);
  const [sortBy, setSortBy] = useState<'date' | 'severity'>('date');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [exporting, setExporting] = useState<string | null>(null);

  useEffect(() => {
    setLoading(true);
    apiService.listAnalyses({ limit: 20 }).then((res) => {
      if (res.data) {
        setAnalyses(res.data);
      } else {
        setToast(res.error || 'Failed to fetch recent analysis data.');
      }
      setLoading(false);
    }).catch(() => {
      setToast('Failed to fetch recent analysis data.');
      setLoading(false);
    });
  }, []);

  const handleRowClick = async (id: string) => {
    setSelectedId(id);
    setModalLoading(true);
    setModalData(null);
    try {
      const res = await apiService.getAnalysis(id);
      if (res.data) {
        setModalData(res.data);
      } else {
        setToast(res.error || 'Failed to fetch analysis details.');
        setSelectedId(null);
      }
    } catch {
      setToast('Failed to fetch analysis details.');
      setSelectedId(null);
    } finally {
      setModalLoading(false);
    }
  };

  const closeModal = () => {
    setSelectedId(null);
    setModalData(null);
    setExporting(null);
  };

  const handleExport = async (format: string) => {
    if (!selectedId) return;
    setExporting(format);
    try {
      const res = await apiService.exportAnalysis(selectedId, format);
      const downloadUrl = (res.data as any)?.download_url;
      if (downloadUrl) {
        window.open(downloadUrl, '_blank');
      } else {
        setToast(res.error || 'Export failed.');
      }
    } catch {
      setToast('Export failed.');
    } finally {
      setExporting(null);
    }
  };

  // Filtering and sorting
  const filtered = analyses.filter(a => filterStatus === 'all' || a.status === filterStatus);
  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'date') {
      return (b.created_at || '').localeCompare(a.created_at || '');
    } else {
      // Sort by critical issues desc
      return (b.summary?.critical_issues || 0) - (a.summary?.critical_issues || 0);
    }
  });

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-6 text-gray-700">
      <h2 className="text-lg font-semibold mb-2">Recent Analysis</h2>
      {/* Filter/Sort Controls */}
      <div className="flex flex-wrap items-center gap-4 mb-4">
        <label className="text-sm">Filter:
          <select className="ml-2 border rounded px-2 py-1" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
            <option value="all">All</option>
            <option value="completed">Completed</option>
            <option value="pending">Pending</option>
            <option value="failed">Failed</option>
          </select>
        </label>
        <label className="text-sm">Sort by:
          <select className="ml-2 border rounded px-2 py-1" value={sortBy} onChange={e => setSortBy(e.target.value as any)}>
            <option value="date">Date</option>
            <option value="severity">Critical Issues</option>
          </select>
        </label>
      </div>
      {loading ? (
        <p>Loading recent analyses...</p>
      ) : sorted.length === 0 ? (
        <p>No recent analysis data available.</p>
      ) : (
        <ul className="divide-y divide-gray-100">
          {sorted.map((a) => (
            <li
              key={a.analysis_id}
              className="py-3 flex flex-col md:flex-row md:items-center md:justify-between cursor-pointer hover:bg-blue-50 rounded transition-colors"
              onClick={() => handleRowClick(a.analysis_id)}
              tabIndex={0}
              role="button"
              aria-label="View analysis details"
            >
              <div>
                <div className="font-medium text-gray-900">{a.summary?.project_name || a.analysis_id}</div>
                <div className="text-xs text-gray-500">{a.created_at || 'Unknown date'}</div>
                <div className="text-xs text-gray-500">Status: <span className="font-semibold">{a.status}</span></div>
              </div>
              <div className="mt-2 md:mt-0 flex flex-col md:items-end">
                <div className="text-xs text-gray-700">Files: {a.summary?.total_files ?? '-'}, Lines: {a.summary?.total_lines ?? '-'}</div>
                <div className="text-xs text-gray-700">Critical: {a.summary?.critical_issues ?? 0}, High: {a.summary?.high_issues ?? 0}</div>
                <div className="text-xs text-gray-700">Duration: {a.duration_seconds ? `${a.duration_seconds}s` : '-'}</div>
              </div>
            </li>
          ))}
        </ul>
      )}
      {/* Modal for details */}
      {selectedId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl p-8 max-w-2xl w-full relative">
            <button
              className="absolute top-3 right-3 text-gray-400 hover:text-gray-700"
              onClick={closeModal}
              aria-label="Close details modal"
            >
              ×
            </button>
            {modalLoading ? (
              <div className="flex items-center justify-center h-40">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
              </div>
            ) : modalData ? (
              <div>
                <h3 className="text-xl font-bold mb-2">Analysis Details</h3>
                <div className="mb-2 text-sm text-gray-600">ID: {modalData.analysis_id}</div>
                <div className="mb-2 text-sm text-gray-600">Status: <span className="font-semibold">{modalData.status}</span></div>
                <div className="mb-2 text-sm text-gray-600">Duration: {modalData.duration_seconds}s</div>
                <div className="mb-2 text-sm text-gray-600">Summary:</div>
                <pre className="bg-gray-50 rounded p-2 text-xs mb-4 overflow-x-auto">{JSON.stringify(modalData.summary, null, 2)}</pre>
                <div className="mb-2 text-sm text-gray-600">Findings ({modalData.findings?.length || 0}):</div>
                {modalData.findings && modalData.findings.length > 0 ? (
                  <ul className="max-h-48 overflow-y-auto text-xs bg-gray-50 rounded p-2">
                    {modalData.findings.map((f: any, i: number) => (
                      <li key={i} className="mb-2 border-b border-gray-200 pb-2 last:border-b-0 last:pb-0">
                        <div><span className="font-semibold">{f.severity?.toUpperCase()}</span> [{f.finding_type}] - {f.title}</div>
                        <div className="text-gray-700">{f.description}</div>
                        {f.recommendation && <div className="text-blue-700">Recommendation: {f.recommendation}</div>}
                        <div className="text-gray-500">{f.file_path}:{f.line_start}</div>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <div className="text-xs text-gray-500">No findings.</div>
                )}
                {/* Export buttons */}
                <div className="mt-4 flex flex-wrap gap-3">
                  {EXPORT_FORMATS.map(f => (
                    <button
                      key={f.value}
                      className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors border ${exporting === f.value ? 'bg-blue-600 text-white' : 'bg-white text-blue-700 border-blue-200 hover:bg-blue-50'}`}
                      onClick={() => handleExport(f.value)}
                      disabled={!!exporting}
                    >
                      {exporting === f.value ? 'Exporting...' : `Export as ${f.label}`}
                    </button>
                  ))}
                  {/* Link to full report (placeholder) */}
                  <a
                    href={`#full-report-${modalData.analysis_id}`}
                    className="px-4 py-2 rounded-lg font-medium text-sm border border-gray-300 text-gray-700 hover:bg-gray-100 transition-colors"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    View Full Report
                  </a>
                </div>
              </div>
            ) : (
              <div className="text-red-600">Failed to load analysis details.</div>
            )}
          </div>
        </div>
      )}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-red-600 text-white px-6 py-3 rounded-lg shadow-lg animate-fade-in">
          {toast}
        </div>
      )}
    </div>
  );
}