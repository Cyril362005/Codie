import React from 'react';
import { Shield, AlertTriangle, CheckCircle, Clock, ExternalLink, ArrowRight } from 'lucide-react';
import apiService from '../../services/api';

interface SecurityFinding {
  id: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  title: string;
  description: string;
  file: string;
  line: number;
  cve?: string;
  confidence: number;
  remediation: string;
  status: 'open' | 'in_progress' | 'resolved';
}

const securityFindings: SecurityFinding[] = [
  {
    id: '1',
    severity: 'critical',
    title: 'SQL Injection Vulnerability',
    description: 'User input is directly concatenated into SQL query without proper validation or parameterization',
    file: 'api/users.js',
    line: 42,
    cve: 'CVE-2023-1234',
    confidence: 95,
    remediation: 'Use parameterized queries or prepared statements',
    status: 'open'
  },
  {
    id: '2',
    severity: 'high',
    title: 'Cross-Site Scripting (XSS)',
    description: 'User input is rendered without proper sanitization, allowing script injection',
    file: 'components/UserProfile.tsx',
    line: 28,
    cve: 'CVE-2023-5678',
    confidence: 88,
    remediation: 'Sanitize user input before rendering or use content security policy',
    status: 'in_progress'
  },
  {
    id: '3',
    severity: 'medium',
    title: 'Insecure Dependencies',
    description: 'Using outdated version of Express.js with known security vulnerabilities',
    file: 'package.json',
    line: 15,
    confidence: 92,
    remediation: 'Update Express.js to version 4.18.2 or later',
    status: 'open'
  },
  {
    id: '4',
    severity: 'low',
    title: 'Weak Password Requirements',
    description: 'Password validation allows weak passwords that are easily guessable',
    file: 'utils/validation.js',
    line: 67,
    confidence: 75,
    remediation: 'Implement stronger password requirements (min 12 chars, mixed case, numbers, symbols)',
    status: 'resolved'
  }
];

export default function SecurityDashboard() {
  const [findings, setFindings] = React.useState<SecurityFinding[]>(securityFindings);
  const [summary, setSummary] = React.useState({
    total_findings: 4,
    critical_count: 1,
    high_count: 1,
    medium_count: 1,
    low_count: 1,
    resolved_count: 1,
    avg_confidence: 87
  });
  const [loading, setLoading] = React.useState(false);
  const [toast, setToast] = React.useState<string | null>(null);
  const [selectedFinding, setSelectedFinding] = React.useState<SecurityFinding | null>(null);
  const [exporting, setExporting] = React.useState(false);

  React.useEffect(() => {
    const fetchSecurityData = async () => {
      setLoading(true);
      try {
        // Fetch security summary
        const summaryResponse = await apiService.getSecuritySummary();
        if (summaryResponse.data) {
          setSummary(summaryResponse.data);
        }

        // Fetch security findings
        const findingsResponse = await apiService.listSecurityFindings({ limit: 20 });
        if (findingsResponse.data) {
          const transformedFindings = findingsResponse.data.map((finding: any) => ({
            id: finding.id,
            severity: finding.severity,
            title: finding.title,
            description: finding.description,
            file: finding.file_path,
            line: finding.line_number,
            cve: finding.cve_id,
            confidence: Math.round(finding.confidence * 100),
            remediation: finding.remediation,
            status: finding.status
          }));
          setFindings(transformedFindings);
        }
      } catch (error) {
        setToast('Failed to fetch security data. Showing last known results.');
      } finally {
        setLoading(false);
      }
    };

    fetchSecurityData();
  }, []);

  const handleScanAgain = async () => {
    setLoading(true);
    setToast(null);
    try {
      const res = await apiService.startSecurityScan('demo-repo-id'); // Replace with real repo ID if available
      if (res.data && res.data.status === 'started') {
        setToast('Security scan started. Refreshing results...');
        // Optionally poll for scan completion, here we just refetch after a delay
        setTimeout(async () => {
          await fetchSecurityData();
          setToast('Security scan complete!');
        }, 2000);
      } else {
        setToast('Failed to start security scan.');
      }
    } catch (e) {
      setToast('Failed to start security scan.');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async () => {
    setExporting(true);
    setToast(null);
    try {
      // TODO: Replace 'demo-analysis-id' with real analysis ID if available
      const res = await apiService.exportAnalysis('demo-analysis-id', 'pdf');
      const downloadUrl = (res.data as any)?.download_url;
      if (downloadUrl) {
        window.open(downloadUrl, '_blank');
        setToast('Export started. Your download should begin shortly.');
      } else {
        setToast(res.error || 'Export failed.');
      }
    } catch {
      setToast('Export failed.');
    } finally {
      setExporting(false);
    }
  };

  const fetchSecurityData = async () => {
    try {
      const summaryResponse = await apiService.getSecuritySummary();
      if (summaryResponse.data) {
        setSummary(summaryResponse.data);
      }
      const findingsResponse = await apiService.listSecurityFindings({ limit: 20 });
      if (findingsResponse.data) {
        const transformedFindings = findingsResponse.data.map((finding: any) => ({
          id: finding.id,
          severity: finding.severity,
          title: finding.title,
          description: finding.description,
          file: finding.file_path,
          line: finding.line_number,
          cve: finding.cve_id,
          confidence: Math.round(finding.confidence * 100),
          remediation: finding.remediation,
          status: finding.status
        }));
        setFindings(transformedFindings);
      }
    } catch (error) {
      setToast('Failed to refresh security data. Showing last known results.');
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'in_progress':
        return 'bg-yellow-50 text-yellow-700 border-yellow-200';
      case 'resolved':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical':
      case 'high':
        return <AlertTriangle className="w-4 h-4" />;
      case 'medium':
        return <Clock className="w-4 h-4" />;
      case 'low':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <Shield className="w-4 h-4" />;
    }
  };

  const criticalCount = summary.critical_count;
  const highCount = summary.high_count;
  const openCount = findings.filter(f => f.status === 'open').length;
  const avgConfidence = summary.avg_confidence;

  return (
    <div className="space-y-6">
      {/* Security Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Critical Issues</p>
              <p className="text-2xl font-bold text-red-600">{criticalCount}</p>
            </div>
            <AlertTriangle className="w-8 h-8 text-red-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">High Priority</p>
              <p className="text-2xl font-bold text-orange-600">{highCount}</p>
            </div>
            <Shield className="w-8 h-8 text-orange-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Open Issues</p>
              <p className="text-2xl font-bold text-gray-900">{openCount}</p>
            </div>
            <Clock className="w-8 h-8 text-gray-500" />
          </div>
        </div>
        
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg Confidence</p>
              <p className="text-2xl font-bold text-emerald-600">{avgConfidence}%</p>
            </div>
            <CheckCircle className="w-8 h-8 text-emerald-500" />
          </div>
        </div>
      </div>

      {/* Security Findings */}
      <div className="bg-white rounded-lg border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Security Findings</h2>
            <div className="flex items-center space-x-2">
              <button
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                onClick={handleExport}
                disabled={exporting}
              >
                {exporting ? 'Exporting...' : 'Export Report'}
              </button>
              <button onClick={handleScanAgain} disabled={loading} className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors">
                Scan Again
              </button>
            </div>
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {loading ? (
            <div className="flex items-center justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            </div>
          ) : (
            findings.map((finding) => (
            <div key={finding.id} className="p-6 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-3 mb-2">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${getSeverityColor(finding.severity)}`}>
                      {getSeverityIcon(finding.severity)}
                      <span className="ml-1 capitalize">{finding.severity}</span>
                    </span>
                    
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(finding.status)}`}>
                      {finding.status.replace('_', ' ').toUpperCase()}
                    </span>
                    
                    <span className="text-xs text-gray-500">
                      {finding.confidence}% confidence
                    </span>
                  </div>
                  
                  <h3 className="text-lg font-medium text-gray-900 mb-2">{finding.title}</h3>
                  <p className="text-gray-600 mb-3">{finding.description}</p>
                  
                  <div className="flex items-center space-x-4 text-sm text-gray-500 mb-3">
                    <span>{finding.file}:{finding.line}</span>
                    {finding.cve && (
                      <div className="flex items-center space-x-1">
                        <ExternalLink className="w-3 h-3" />
                        <a 
                          href={`https://cve.mitre.org/cgi-bin/cvename.cgi?name=${finding.cve}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:text-blue-700 font-medium"
                        >
                          {finding.cve}
                        </a>
                      </div>
                    )}
                  </div>
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                    <div className="flex items-start space-x-2">
                      <ArrowRight className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-blue-900 mb-1">Recommended Fix:</p>
                        <p className="text-sm text-blue-800">{finding.remediation}</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="ml-6 flex-shrink-0">
                  <button
                    className="px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                    onClick={() => setSelectedFinding(finding)}
                  >
                    View Details
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
      {/* Security Recommendations */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Security Recommendations</h3>
        <div className="space-y-4">
          <div className="flex items-start space-x-3 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-yellow-900">Immediate Action Required</p>
              <p className="text-sm text-yellow-800 mt-1">
                Address the SQL injection vulnerability immediately as it poses a critical security risk to your application.
              </p>
            </div>
          </div>
          <div className="flex items-start space-x-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <Shield className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-blue-900">Security Best Practices</p>
              <p className="text-sm text-blue-800 mt-1">
                Implement a Content Security Policy (CSP) to prevent XSS attacks and regularly audit your dependencies for known vulnerabilities.
              </p>
            </div>
          </div>
          <div className="flex items-start space-x-3 p-3 bg-emerald-50 border border-emerald-200 rounded-lg">
            <CheckCircle className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-emerald-900">Continuous Monitoring</p>
              <p className="text-sm text-emerald-800 mt-1">
                Set up automated security scanning in your CI/CD pipeline to catch vulnerabilities early in the development process.
              </p>
            </div>
          </div>
        </div>
      </div>
      {selectedFinding && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-2xl p-8 max-w-lg w-full relative">
            <button
              className="absolute top-3 right-3 text-gray-400 hover:text-gray-700"
              onClick={() => setSelectedFinding(null)}
              aria-label="Close details modal"
            >
              ×
            </button>
            <h2 className="text-xl font-bold mb-2">{selectedFinding.title}</h2>
            <div className="mb-2 text-sm text-gray-600">{selectedFinding.file}:{selectedFinding.line}</div>
            <div className="mb-4 text-gray-800">{selectedFinding.description}</div>
            {selectedFinding.cve && (
              <div className="mb-2">
                <span className="font-medium">CVE:</span> <a href={`https://cve.mitre.org/cgi-bin/cvename.cgi?name=${selectedFinding.cve}`} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">{selectedFinding.cve}</a>
              </div>
            )}
            <div className="mb-2">
              <span className="font-medium">Severity:</span> {selectedFinding.severity}
            </div>
            <div className="mb-2">
              <span className="font-medium">Confidence:</span> {selectedFinding.confidence}%
            </div>
            <div className="mb-2">
              <span className="font-medium">Status:</span> {selectedFinding.status}
            </div>
            <div className="mb-4 bg-blue-50 border border-blue-200 rounded-lg p-3">
              <div className="flex items-start space-x-2">
                <ArrowRight className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <p className="text-sm font-medium text-blue-900 mb-1">Recommended Fix:</p>
                  <p className="text-sm text-blue-800">{selectedFinding.remediation}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-600 text-white px-6 py-3 rounded-lg shadow-lg animate-fade-in">
          {toast}
        </div>
      )}
    </div>
  );
}