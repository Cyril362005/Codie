import React, { useState, useRef, useEffect } from 'react';
import { Eye, EyeOff, Github, Mail, Loader2, X } from 'lucide-react';
import useAuth from '../../hooks/useAuth';

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
  contextMessage?: string;
}

type Tab = 'login' | 'signup' | 'forgot';

const initialState = {
  email: '',
  password: '',
  confirmPassword: '',
  remember: true,
  error: '',
  passwordVisible: false,
  passwordStrength: 0,
  passwordTouched: false,
};

function validateEmail(email: string) {
  return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email);
}

const passwordRules = [
  { label: 'At least 8 characters', test: (pw: string) => pw.length >= 8 },
  { label: 'A number', test: (pw: string) => /[0-9]/.test(pw) },
  { label: 'A symbol', test: (pw: string) => /[^A-Za-z0-9]/.test(pw) },
];

const AuthModal: React.FC<AuthModalProps> = ({ open, onClose, contextMessage }) => {
  const [tab, setTab] = useState<Tab>('login');
  const [state, setState] = useState(initialState);
  const [showPassword, setShowPassword] = useState(false);
  const emailRef = useRef<HTMLInputElement>(null);
  const modalRef = useRef<HTMLDivElement>(null);
  const { login, register, loading, error, setError } = useAuth();

  useEffect(() => {
    if (open) {
      setTimeout(() => emailRef.current?.focus(), 100);
    }
  }, [open, tab]);

  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose();
    }
    if (open) {
      window.addEventListener('keydown', handleKey);
      return () => window.removeEventListener('keydown', handleKey);
    }
  }, [open, onClose]);

  // Focus trap
  useEffect(() => {
    if (!open) return;
    const focusable = modalRef.current?.querySelectorAll<HTMLElement>(
      'input,button,select,textarea,a[href],area[href],iframe,object,embed,[tabindex]:not([tabindex="-1"])'
    );
    const first = focusable?.[0];
    const last = focusable?.[focusable.length - 1];
    function trap(e: KeyboardEvent) {
      if (e.key !== 'Tab') return;
      if (document.activeElement === last && !e.shiftKey) {
        e.preventDefault();
        first?.focus();
      } else if (document.activeElement === first && e.shiftKey) {
        e.preventDefault();
        last?.focus();
      }
    }
    modalRef.current?.addEventListener('keydown', trap);
    return () => modalRef.current?.removeEventListener('keydown', trap);
  }, [open]);

  useEffect(() => {
    if (!open) setState(initialState);
    setError && setError(null);
  }, [open, setError]);

  const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    setState((s) => ({ ...s, [e.target.name]: e.target.value, error: '' }));
    setError && setError(null);
  };

  const handleRemember = (e: React.ChangeEvent<HTMLInputElement>) => {
    setState((s) => ({ ...s, remember: e.target.checked }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setState((s) => ({ ...s, error: '' }));
    setError && setError(null);
    if (tab === 'login') {
      const ok = await login(state.email, state.password);
      if (ok) {
        setState(initialState);
        onClose();
      }
    } else if (tab === 'signup') {
      if (state.password !== state.confirmPassword) {
        setState((s) => ({ ...s, error: 'Passwords do not match' }));
        return;
      }
      const ok = await register(state.email, state.password);
      if (ok) {
        setState(initialState);
        onClose();
      }
    } else if (tab === 'forgot') {
      // TODO: Implement forgot password
      setState((s) => ({ ...s, error: 'Password reset not implemented.' }));
    }
  };

  const canSubmit =
    tab === 'login'
      ? validateEmail(state.email) && state.password.length >= 8 && !loading
      : tab === 'signup'
      ? validateEmail(state.email) &&
        state.password.length >= 8 &&
        state.password === state.confirmPassword &&
        !loading
      : tab === 'forgot'
      ? validateEmail(state.email) && !loading
      : false;

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-blur-sm">
      <div
        ref={modalRef}
        className="bg-white rounded-xl shadow-2xl p-8 min-w-[350px] max-w-full w-full sm:w-[400px] relative focus:outline-none"
        role="dialog"
        aria-modal="true"
        aria-labelledby="auth-modal-title"
      >
        <button
          className="absolute top-3 right-3 text-gray-400 hover:text-gray-700"
          onClick={onClose}
          aria-label="Close auth modal"
        >
          <X className="w-5 h-5" />
        </button>
        <div className="mb-6 flex justify-center gap-4">
          <button
            className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${tab === 'login' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`}
            onClick={() => setTab('login')}
            aria-selected={tab === 'login'}
          >
            Login
          </button>
          <button
            className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${tab === 'signup' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`}
            onClick={() => setTab('signup')}
            aria-selected={tab === 'signup'}
          >
            Sign Up
          </button>
          <button
            className={`px-4 py-2 rounded-lg font-medium text-sm transition-colors ${tab === 'forgot' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700'}`}
            onClick={() => setTab('forgot')}
            aria-selected={tab === 'forgot'}
          >
            Forgot Password
          </button>
        </div>
        {/* SSO Buttons */}
        <div className="flex flex-col gap-2 mb-4">
          <button className="flex items-center justify-center gap-2 border border-gray-200 rounded-lg py-2 hover:bg-gray-50 transition-colors" aria-label="Sign in with GitHub">
            <Github className="w-5 h-5" /> Sign in with GitHub
          </button>
          <button className="flex items-center justify-center gap-2 border border-gray-200 rounded-lg py-2 hover:bg-gray-50 transition-colors" aria-label="Sign in with Google">
            <Mail className="w-5 h-5" /> Sign in with Google
          </button>
        </div>
        <div className="flex items-center my-4">
          <div className="flex-1 h-px bg-gray-200" />
          <span className="px-2 text-xs text-gray-400">or</span>
          <div className="flex-1 h-px bg-gray-200" />
        </div>
        {contextMessage && (
          <div className="mb-2 text-sm text-blue-700 bg-blue-50 border border-blue-200 rounded p-2 text-center">
            {contextMessage}
          </div>
        )}
        <form onSubmit={handleSubmit} className="space-y-4" aria-labelledby="auth-modal-title">
          <label className="block text-sm font-medium text-gray-700" htmlFor="email">Email</label>
          <input
            ref={emailRef}
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${state.email && !validateEmail(state.email) ? 'border-red-500' : 'border-gray-300'}`}
            value={state.email}
            onChange={handleInput}
            aria-invalid={!!state.email && !validateEmail(state.email)}
            aria-describedby="email-error"
            required
          />
          {state.email && !validateEmail(state.email) && (
            <div id="email-error" className="text-xs text-red-600">Invalid email format</div>
          )}

          {(tab === 'login' || tab === 'signup') && (
            <>
              <label className="block text-sm font-medium text-gray-700" htmlFor="password">Password</label>
              <div className="relative">
                <input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete={tab === 'signup' ? 'new-password' : 'current-password'}
                  className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${state.password && state.password.length < 8 ? 'border-red-500' : 'border-gray-300'}`}
                  value={state.password}
                  onChange={handleInput}
                  onFocus={() => setState((s) => ({ ...s, passwordTouched: true }))}
                  aria-invalid={!!state.password && state.password.length < 8}
                  aria-describedby="password-error"
                  required
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-700"
                  onClick={() => setShowPassword((v) => !v)}
                  tabIndex={0}
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              {tab === 'signup' && (
                <>
                  <label className="block text-sm font-medium text-gray-700" htmlFor="confirmPassword">Confirm Password</label>
                  <input
                    id="confirmPassword"
                    name="confirmPassword"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="new-password"
                    className={`w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 ${state.confirmPassword && state.confirmPassword !== state.password ? 'border-red-500' : 'border-gray-300'}`}
                    value={state.confirmPassword}
                    onChange={handleInput}
                    required
                  />
                  {state.confirmPassword && state.confirmPassword !== state.password && (
                    <div className="text-xs text-red-600">Passwords do not match</div>
                  )}
                </>
              )}
              <div className="flex items-center justify-between mt-2">
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="checkbox"
                    checked={state.remember}
                    onChange={handleRemember}
                    className="rounded border-gray-300"
                  />
                  Remember me
                  <span className="ml-1 text-gray-400" title="Keep me signed in on this device">?</span>
                </label>
                {tab === 'login' && (
                  <button
                    type="button"
                    className="text-xs text-blue-600 hover:underline"
                    onClick={() => setTab('forgot')}
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              {/* Password strength feedback */}
              {state.passwordTouched && (
                <div className="mt-2 space-y-1">
                  {passwordRules.map((rule) => (
                    <div key={rule.label} className="flex items-center gap-2 text-xs">
                      {rule.test(state.password) ? (
                        <span className="text-emerald-600">✔</span>
                      ) : (
                        <span className="text-gray-400">✗</span>
                      )}
                      <span>{rule.label}</span>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {tab === 'signup' && (
            <div className="text-xs text-gray-500 mt-2">
              By signing up, you agree to our <a href="#" className="text-blue-600 hover:underline">Terms of Service</a> and <a href="#" className="text-blue-600 hover:underline">Privacy Policy</a>.
            </div>
          )}

          {tab === 'forgot' && (
            <div className="text-xs text-gray-600 mb-2">Enter your email and we’ll send you a password reset link.</div>
          )}

          {(state.error || error) && (
            <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded p-2 mt-2" role="alert">
              {state.error || error}
            </div>
          )}

          <button
            type="submit"
            className="w-full mt-2 py-2 rounded-lg bg-blue-600 text-white font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={!canSubmit}
            aria-disabled={!canSubmit}
          >
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : tab === 'login' ? 'Login' : tab === 'signup' ? 'Sign Up' : 'Send Reset Link'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default AuthModal; 