import React, { useEffect, useState } from 'react';
import { Folder, Plus, RefreshCw, Edit, Trash2, Sync } from 'lucide-react';
import { useRepositories } from '../hooks/useRepositories';
import { Repository } from '../types/Repository';

export default function RepositoryManager() {
  const {
    repositories,
    loading,
    error,
    success,
    fetchRepositories,
    createRepository,
    updateRepository,
    deleteRepository,
    syncRepository,
    setError,
    setSuccess,
  } = useRepositories();

  const [modalOpen, setModalOpen] = useState(false);
  const [editRepo, setEditRepo] = useState<Repository | null>(null);
  const [form, setForm] = useState({ name: '', description: '', url: '' });

  useEffect(() => {
    fetchRepositories();
  }, [fetchRepositories]);

  useEffect(() => {
    if (success) {
      setTimeout(() => setSuccess(null), 2500);
      setModalOpen(false);
      setEditRepo(null);
      setForm({ name: '', description: '', url: '' });
    }
  }, [success, setSuccess]);

  const openCreate = () => {
    setEditRepo(null);
    setForm({ name: '', description: '', url: '' });
    setModalOpen(true);
  };

  const openEdit = (repo: Repository) => {
    setEditRepo(repo);
    setForm({ name: repo.name, description: repo.description || '', url: repo.url || '' });
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) {
      setError('Repository name is required');
      return;
    }
    if (editRepo) {
      await updateRepository(editRepo.id, form);
    } else {
      await createRepository(form);
    }
  };

  return (
    <div className="max-w-5xl mx-auto py-10">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <Folder className="w-7 h-7 text-blue-600" />
          <h1 className="text-2xl font-bold text-gray-900">Manage Repositories</h1>
        </div>
        <div className="flex gap-2">
          <button
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-2xl shadow hover:bg-blue-700 transition"
            onClick={openCreate}
          >
            <Plus className="w-5 h-5" /> New Repository
          </button>
          <button
            className="p-2 bg-white/60 backdrop-blur border border-gray-200 rounded-2xl hover:bg-blue-50 transition"
            onClick={fetchRepositories}
            aria-label="Refresh"
          >
            <RefreshCw className="w-5 h-5 text-blue-600" />
          </button>
        </div>
      </div>
      {/* Table */}
      <div className="bg-white/60 backdrop-blur rounded-2xl shadow border border-gray-200 overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Repo Name</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Description</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-700 uppercase tracking-wider">Last Synced</th>
              <th className="px-6 py-3 text-center text-xs font-medium text-gray-700 uppercase tracking-wider">Actions</th>
            </tr>
          </thead>
          <tbody className="bg-transparent divide-y divide-gray-100">
            {repositories.map((repo) => (
              <tr key={repo.id} className="hover:bg-blue-50/40 transition">
                <td className="px-6 py-4 font-semibold text-gray-900">{repo.name}</td>
                <td className="px-6 py-4 text-gray-700">{repo.description}</td>
                <td className="px-6 py-4 text-gray-500">{repo.updated_at ? new Date(repo.updated_at).toLocaleString() : '-'}</td>
                <td className="px-6 py-4 flex gap-2 justify-center">
                  <button
                    className="p-2 rounded-lg bg-white/80 hover:bg-blue-100 border border-gray-200"
                    onClick={() => openEdit(repo)}
                    aria-label="Edit"
                  >
                    <Edit className="w-4 h-4 text-blue-600" />
                  </button>
                  <button
                    className="p-2 rounded-lg bg-white/80 hover:bg-red-100 border border-gray-200"
                    onClick={() => deleteRepository(repo.id)}
                    aria-label="Delete"
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </button>
                  <button
                    className="p-2 rounded-lg bg-white/80 hover:bg-emerald-100 border border-gray-200"
                    onClick={() => syncRepository(repo.id)}
                    aria-label="Sync"
                  >
                    <Sync className="w-4 h-4 text-emerald-600" />
                  </button>
                </td>
              </tr>
            ))}
            {repositories.length === 0 && !loading && (
              <tr>
                <td colSpan={4} className="px-6 py-8 text-center text-gray-400">No repositories found.</td>
              </tr>
            )}
          </tbody>
        </table>
        {loading && <div className="p-6 text-center text-blue-600 animate-pulse">Loading...</div>}
      </div>
      {/* Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md relative">
            <button
              className="absolute top-3 right-3 text-gray-400 hover:text-gray-700"
              onClick={() => { setModalOpen(false); setEditRepo(null); setForm({ name: '', description: '', url: '' }); }}
              aria-label="Close modal"
            >
              ×
            </button>
            <h2 className="text-xl font-semibold mb-4 text-gray-900">{editRepo ? 'Edit Repository' : 'New Repository'}</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Name <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 border-gray-300"
                  value={form.name}
                  onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Description</label>
                <input
                  type="text"
                  className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 border-gray-300"
                  value={form.description}
                  onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">Git URL <span className="text-gray-400">(optional)</span></label>
                <input
                  type="url"
                  className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 border-gray-300"
                  value={form.url}
                  onChange={e => setForm(f => ({ ...f, url: e.target.value }))}
                  placeholder="https://github.com/user/repo"
                />
              </div>
              {(error || success) && (
                <div className={`text-sm rounded p-2 ${error ? 'bg-red-50 text-red-600 border border-red-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>{error || success}</div>
              )}
              <div className="flex gap-2 mt-4">
                <button
                  type="submit"
                  className="flex-1 py-2 rounded-lg bg-blue-600 text-white font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={loading}
                >
                  {editRepo ? 'Update' : 'Create'}
                </button>
                <button
                  type="button"
                  className="flex-1 py-2 rounded-lg bg-gray-100 text-gray-700 font-semibold hover:bg-gray-200 transition-colors"
                  onClick={() => { setModalOpen(false); setEditRepo(null); setForm({ name: '', description: '', url: '' }); }}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Toasts */}
      {(error || success) && (
        <div className={`fixed bottom-6 right-6 z-50 px-6 py-3 rounded-lg shadow-lg animate-fade-in ${error ? 'bg-red-600 text-white' : 'bg-emerald-600 text-white'}`}>{error || success}</div>
      )}
    </div>
  );
} 