import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Code, Copy, ThumbsUp, ThumbsDown, Loader2 } from 'lucide-react';
import apiService from '../../services/api';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
  codeSnippet?: string;
  language?: string;
}

const initialMessages: Message[] = [
  {
    id: '1',
    type: 'bot',
    content: "Hi! I'm Codie, your AI code review assistant. I've analyzed your code and found several areas for improvement. Would you like me to explain any specific findings or help you understand how to fix them?",
    timestamp: new Date(Date.now() - 5 * 60 * 1000)
  },
  {
    id: '2',
    type: 'user',
    content: "Can you explain the security vulnerability you found on line 9?",
    timestamp: new Date(Date.now() - 4 * 60 * 1000)
  },
  {
    id: '3',
    type: 'bot',
    content: "The security issue on line 9 is a potential SQL injection vulnerability. You're passing the `userId` parameter directly to `fetchUserData()` without validation. Here's what's happening and how to fix it:",
    timestamp: new Date(Date.now() - 3 * 60 * 1000),
    codeSnippet: `// ❌ Vulnerable code
const userData = await fetchUserData(userId);

// ✅ Safe approach
const validateUserId = (id) => {
  if (typeof id !== 'string' || !/^[a-zA-Z0-9-_]+$/.test(id)) {
    throw new Error('Invalid user ID format');
  }
  return id;
};

const userData = await fetchUserData(validateUserId(userId));`,
    language: 'javascript'
  }
];

export default function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (event?: React.MouseEvent | React.KeyboardEvent, suggestion?: string) => {
    if (event) event.preventDefault();
    const messageToSend = (suggestion ?? inputMessage).trim();
    if (!messageToSend) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: messageToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    try {
      // Send message to AI service
      const response = await apiService.sendChatMessage({
        message: messageToSend,
        context: { file_path: 'current_analysis' },
        conversation_history: messages.slice(-10) // Last 10 messages for context
      });

      if (response.data) {
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: 'bot',
          content: response.data.message,
          timestamp: new Date(),
          codeSnippet: response.data.suggestions?.[0]?.code,
          language: 'javascript'
        };
        setMessages(prev => [...prev, botMessage]);
      } else {
        // Fallback to mock response
        const botMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: 'bot',
          content: generateBotResponse(messageToSend),
          timestamp: new Date()
        };
        setMessages(prev => [...prev, botMessage]);
      }
    } catch (error) {
      console.error('Chat API error:', error);
      setToast('Failed to connect to AI service. Please try again later.');
      // Fallback to mock response
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: "I'm sorry, I'm having trouble connecting right now. Please try again later.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const generateBotResponse = (userInput: string): string => {
    const responses = {
      performance: "Great question about performance! The `formatUserData` function is being recreated on every render, which can cause unnecessary re-renders of child components. Wrapping it with `useCallback` will memoize the function and only recreate it when its dependencies change.",
      logging: "You're right to ask about the logging issue. Using `console.log` in production code is not recommended because it can expose sensitive information and impact performance. Consider using a proper logging library like Winston or a service like LogRocket.",
      refactor: "I'd recommend starting with the security issue first since it has the highest impact. Then tackle the performance optimization with `useCallback`, and finally clean up the logging. This prioritization ensures you address the most critical issues first.",
      testing: "For this component, I'd suggest adding tests for: 1) Loading state display, 2) Error handling when fetchUserData fails, 3) Proper rendering of user data, 4) Behavior with invalid userId. Would you like me to generate some test cases?"
    };

    const lowercaseInput = userInput.toLowerCase();
    if (lowercaseInput.includes('performance') || lowercaseInput.includes('callback')) {
      return responses.performance;
    } else if (lowercaseInput.includes('log') || lowercaseInput.includes('console')) {
      return responses.logging;
    } else if (lowercaseInput.includes('refactor') || lowercaseInput.includes('fix') || lowercaseInput.includes('order')) {
      return responses.refactor;
    } else if (lowercaseInput.includes('test')) {
      return responses.testing;
    }

    return "I understand you're asking about the code analysis. Could you be more specific about which finding you'd like me to explain? I can help you understand security vulnerabilities, performance issues, code style suggestions, or provide refactoring guidance.";
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
  };

  const formatTime = (timestamp: Date) => {
    return timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const handleQuickSuggestion = (suggestion: string) => {
    void handleSendMessage(undefined, suggestion);
  };

  return (
    <div className="flex flex-col h-full bg-white">
      {/* Chat Header */}
      <div className="border-b border-gray-200 p-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-blue-700 rounded-full flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">Codie AI Assistant</h3>
            <p className="text-sm text-gray-600">Ask me about your code analysis results</p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex items-start space-x-3 ${
              message.type === 'user' ? 'flex-row-reverse space-x-reverse' : ''
            }`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
              message.type === 'user' 
                ? 'bg-gray-600' 
                : 'bg-gradient-to-br from-blue-600 to-blue-700'
            }`}>
              {message.type === 'user' ? (
                <User className="w-4 h-4 text-white" />
              ) : (
                <Bot className="w-4 h-4 text-white" />
              )}
            </div>
            
            <div className={`flex-1 max-w-3xl ${
              message.type === 'user' ? 'text-right' : ''
            }`}>
              <div className={`inline-block p-3 rounded-lg ${
                message.type === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-900'
              }`}>
                <p className="text-sm">{message.content}</p>
                
                {message.codeSnippet && (
                  <div className="mt-3 bg-gray-900 rounded-lg p-3 text-sm font-mono">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-gray-400 text-xs">{message.language}</span>
                      <button
                        onClick={() => copyCode(message.codeSnippet!)}
                        className="text-gray-400 hover:text-white transition-colors"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                    <pre className="text-green-400 whitespace-pre-wrap overflow-x-auto">
                      {message.codeSnippet}
                    </pre>
                  </div>
                )}
              </div>
              
              <div className="flex items-center justify-between mt-2">
                <span className="text-xs text-gray-500">{formatTime(message.timestamp)}</span>
                
                {message.type === 'bot' && (
                  <div className="flex items-center space-x-2">
                    <button className="text-gray-400 hover:text-emerald-600 transition-colors">
                      <ThumbsUp className="w-4 h-4" />
                    </button>
                    <button className="text-gray-400 hover:text-red-600 transition-colors">
                      <ThumbsDown className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
        
        {isTyping && (
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-full flex items-center justify-center">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className="bg-gray-100 rounded-lg p-3">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="border-t border-gray-200 p-4">
        <div className="flex space-x-3">
          <input
            ref={inputRef}
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(e)}
            placeholder="Ask me about your code analysis..."
            className="flex-1 border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            disabled={isTyping}
          />
          <button
            onClick={handleSendMessage}
            disabled={!inputMessage.trim() || isTyping}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
        
        <div className="mt-2 flex flex-wrap gap-2">
          {['Explain security issue', 'Show performance fix', 'Suggest refactoring order', 'Generate tests'].map((suggestion) => (
            <button
              key={suggestion}
              onClick={() => handleQuickSuggestion(suggestion)}
              className="text-xs bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-1 rounded-full transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={isTyping}
            >
              {isTyping ? <Loader2 className="w-3 h-3 animate-spin" /> : null}
              {suggestion}
            </button>
          ))}
        </div>
      </div>
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-red-600 text-white px-6 py-3 rounded-lg shadow-lg animate-fade-in">
          {toast}
        </div>
      )}
    </div>
  );
}